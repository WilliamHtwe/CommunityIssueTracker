<?php
require_once 'config.php';
function updateAllUserPoints($pdo) {
    try {
        $query = "UPDATE users u 
                  SET points = (
                      SELECT COALESCE(
                          COUNT(CASE WHEN r.status IN ('confirmed', 'finished') THEN 1 END), 0
                      )
                      FROM reports r 
                      WHERE r.user_id = u.id
                  )";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

updateAllUserPoints($pdo);

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'highest_total';
$query = "SELECT u.id, u.first_name, u.last_name, u.phone_number, u.nrc_number, u.points,
                 COUNT(r.id) as total_reports,
                 COUNT(CASE WHEN r.status = 'confirmed' THEN 1 END) as confirmed_reports,
                 COUNT(CASE WHEN r.status = 'finished' THEN 1 END) as finished_reports,
                 (COUNT(CASE WHEN r.status = 'confirmed' THEN 1 END) + COUNT(CASE WHEN r.status = 'finished' THEN 1 END)) as total_successful
          FROM users u
          LEFT JOIN reports r ON u.id = r.user_id
          WHERE 1=1";

$params = [];
if ($search) {
    $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.phone_number LIKE ? OR u.nrc_number LIKE ?)";
    $searchTerm = "%{$search}%";
    $params = [$searchTerm, $searchTerm, $searchTerm, $searchTerm];
}

$query .= " GROUP BY u.id";
switch ($filter) {
    case 'highest_total':
        $query .= " ORDER BY total_successful DESC, u.first_name, u.last_name";
        break;
    case 'lowest_total':
        $query .= " ORDER BY total_successful ASC, u.first_name, u.last_name";
        break;
    case 'highest_points':
        $query .= " ORDER BY u.points DESC, u.first_name, u.last_name";
        break;
    case 'lowest_points':
        $query .= " ORDER BY u.points ASC, u.first_name, u.last_name";
        break;
    case 'name_asc':
        $query .= " ORDER BY u.first_name, u.last_name";
        break;
    default:
        $query .= " ORDER BY total_successful DESC, u.first_name, u.last_name";
}

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Error loading users. Please try again.";
    $users = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Reward Management - Community Issue Tracker</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

    body {
    font-family: 'Inter', sans-serif;
    background-color: #F3F4F6;
    margin: 0;
    line-height: 1.5;
    padding: 0;
}

.container {
    margin: 0;
    border-radius: 0; 
    border: none; 
    min-height: 100vh; 
    width: 100%; 
    box-shadow: none; 
}

.layout {
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 220px;
    background-color: #0A0A0A;
    color: #E5E7EB;
    padding: 40px 20px;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
}

.sidebar h2 {
    font-size: 24px;
    line-height: 1;
    margin: 0 0 40px 0;
    text-transform: uppercase;
    text-align: left;
}

.sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar ul li {
    margin-bottom: 20px;
}

.sidebar ul li a {
    color: #E5E7EB;
    text-decoration: none;
    font-size: 16px;
    display: block;
    padding: 10px 0; 
}


.main-content {
    margin-left: 220px; 
    flex: 1;
    padding: 20px 40px;
    background: #F3F4F6;
}




        .header {
            text-align: left;
            margin-bottom: 32px;
        }

        .title {
            font-size: 24px;
            line-height: 1;
            color: #0A0A0A;
            margin-bottom: 16px;
        }

        .subtitle {
            font-size: 16px;
            line-height: 1.5;
            color: #0A0A0A;
        }

        .search-section {
            margin-bottom: 32px;
        }

        .search-filter-container {
            display: flex;
            justify-content:flex-start;
            gap: 20px;
            flex-wrap: wrap;
        }

        .search-form {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .filter-form {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .filter-select {
            padding: 12px 24px;
            border: 2px solid #ddd;
            border-radius: 20px;
            font-size: 16px;
            outline: none;
            cursor: pointer;
        }

        .filter-label {
            color: #0A0A0A;
            white-space: nowrap;
        }

        .search-input {
            padding: 12px 24px;
            border: 2px solid #ddd;
            border-radius: 20px;
            font-size: 16px;
            width: 300px;
            outline: none;
            transition: border-color 0.3s;
        }

        .search-btn {
            padding: 10px 24px;
            background:#0A0A0A ;
            color: #E5E7EB;
            border: 2px solid #0A0A0A;
            border-radius: 20px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }

        .search-btn:hover {
            background: #E5E7EB ;
            border: 2px solid #0A0A0A;
            color: #0A0A0A;
        }

        .clear-btn {
            padding: 12px 24px;
            background: #C63A41;
            color:#E5E7EB;
            border: 2px solid #C63A41;
            text-decoration: none;
            border-radius: 20px;
            font-size: 16px;
            transition: transform 0.3s;
        }

        .clear-btn:hover {
            border: 2px solid #C63A41;
            color: #C63A41;
            background-color: #E5E7EB;
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .users-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .user-card {
            background: #E5E7EB;
            border-radius: 20px;
            padding: 20px;
                 border: 1px solid rgba(0, 0, 0, 0.03);
            box-shadow:
            0 2px 4px rgba(0, 0, 0, 0.04),
            0 4px 8px rgba(0, 0, 0, 0.03);
        }

        .user-info {
            margin-bottom: 10px;
        }

        .user-name {
            font-size: 24px;
            color: #0A0A0A;
            margin-bottom: 10px;
        }

        .user-detail {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            line-height: 1.5;
            font-size: 16px;
        }

        .detail-label {
            font-size: 16px;
            color: #0A0A0A;
        }

        .detail-value {
            color: #0A0A0A;
        }

        .stat-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            line-height: 1.5;
            font-size: 16px;
        }

        .confirmed-reports {
            color: #0A0A0A;
        }

        .finished-reports {
            color: #0A0A0A;
        }

        .total-successful {
            color: #0A0A0A;
            font-size: 16px;
        }

        .total-points {
            color: #0A0A0A;
            font-size: 18px;
        }

        .no-users {
            text-align: center;
            color: #0A0A0A;
            font-size: 18px;
            padding: 40px;
        }
    </style>
</head>
<body>
       <div class="layout">
        <!-- Sidebar -->
      <nav class="sidebar">
    <h2>Admin</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="reportreward.php">Reward</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

        <main class="main-content">
                <div class="container">
        <div class="header">
            <h1 class="title">Report Reward Management</h1>
            <p class="subtitle">Manage user points and rewards</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="message error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="search-section">
            <div class="search-filter-container">
                <form method="GET" class="search-form">
                    <input 
                        type="text" 
                        name="search" 
                        class="search-input" 
                        placeholder="Search by phone, or NRC..." 
                        value="<?php echo htmlspecialchars($search); ?>"
                    >
                    <input type="hidden" name="filter" value="<?php echo htmlspecialchars($filter); ?>">
                    <button type="submit" class="search-btn">Search</button>
                    <?php if ($search): ?>
                        <a href="reportreward.php?filter=<?php echo htmlspecialchars($filter); ?>" class="clear-btn">Clear</a>
                    <?php endif; ?>
                </form>

                <form method="GET" class="filter-form">
                    <label class="filter-label">Sort by</label>
                    <select name="filter" class="filter-select" onchange="this.form.submit()">
                        <option value="highest_points" <?php echo $filter === 'highest_points' ? 'selected' : ''; ?>>
                            Highest Points
                        </option>
                        <option value="lowest_points" <?php echo $filter === 'lowest_points' ? 'selected' : ''; ?>>
                            Lowest Points
                        </option>
                        <option value="name_asc" <?php echo $filter === 'name_asc' ? 'selected' : ''; ?>>
                            Name (A-Z)
                        </option>
                    </select>
                    <?php if ($search): ?>
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <?php if (empty($users)): ?>
            <div class="no-users">
                <?php if ($search): ?>
                    No users found matching "<?php echo htmlspecialchars($search); ?>"
                <?php else: ?>
                    No users found in the system.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="users-grid">
                <?php foreach ($users as $user): ?>
                    <div class="user-card">
                        <div class="user-info">
                            <div class="user-name">
                                <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                            </div>
                            
                            <div class="user-detail">
                                <span class="detail-label">Phone</span>
                                <span class="detail-value"><?php echo htmlspecialchars($user['phone_number']); ?></span>
                            </div>
                            
                            <div class="user-detail">
                                <span class="detail-label">NRC</span>
                                <span class="detail-value"><?php echo htmlspecialchars($user['nrc_number']); ?></span>
                            </div>
                        </div>

                        <div class="stats-section">
                            <div class="stat-item">
                                <span class="detail-label">Total Reports</span>
                                <span class="detail-value"><?php echo $user['total_reports']; ?></span>
                            </div>
                            
                            <div class="stat-item">
                                <span class="detail-label">Confirmed Reports</span>
                                <span class="detail-value confirmed-reports"><?php echo $user['confirmed_reports']; ?></span>
                            </div>
                            
                            <div class="stat-item">
                                <span class="detail-label">Finished Reports</span>
                                <span class="detail-value finished-reports"><?php echo $user['finished_reports']; ?></span>
                            </div>
                            
                            <div class="stat-item">
                                <span class="detail-label">Total Successful</span>
                                <span class="detail-value total-successful"><?php echo $user['total_successful']; ?></span>
                            </div>
                            
                            <div class="stat-item">
                                <span class="detail-label">Current Points</span>
                                <span class="detail-value total-points"><?php echo $user['points'] ?? 0; ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div style="text-align: center; margin-top: 30px;">
            <p style="color: #0a0a0a; font-size: 14px;">
                Total Users : <?php echo count($users); ?>
                <?php if ($search): ?>
                    (filtered from search)
                <?php endif; ?>
            </p>
        </div>
    </div>
  </main>
    </div>
    <script>
        <?php if (!$search): ?>
        document.querySelector('.search-input').focus();
        <?php endif; ?>
    </script>
</body>
</html>