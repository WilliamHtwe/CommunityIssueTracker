<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Issue Tracker </title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
   <div class ="body-maincontainer">
        <nav class="mobile-nav">
            <a href="home.php" class="nav-item">
                <img src="./communityimage/icon1.png" alt="Home">
                <span>Home</span>
            </a>
            <a href="report.php" class="nav-item">
                <img src="./communityimage/icon2.png" alt="Search">
                <span>Report</span>
            </a>
            <a href="aboutus.php" class="nav-item">
                <img src="./communityimage/icon3.png" alt="Alerts">
                <span>About Us</span>
            </a>
            <a href="contact.php" class="nav-item">
                <img src="./communityimage/icon4.png" alt="Profile">
                <span>Contact</span>
            </a>
            <a href="check_profile.php" class="nav-item">
                <img src="./communityimage/icon25.png" alt="Profile">
                <span>Profile</span>
            </a>
        </nav>
<section class="contact-section">
  <div class="contact-box">
    <h1>Contact Us</h1>
    <p>We’re here to listen and act. Reach out — every message helps shape safer, stronger communities.</p>
  </div>
</section>
<section class="contact-wrapper">
  <div class="contact-list" id="contactList">
    <div class="contact-item">
      <span class="phone">+95 912 345 678</span>
      <span class="name">Office</span>
    </div>
  </div>
</section>
<div class="contact-us-section">
  <div class="contact-us-box contact-us-left-box">
    <img src="./communityimage/icon20.png" alt="Email Icon" class="contact-us-icon">
    <p class="contact-us-email">issue@mm.gov</p>
  </div>

  <div class="contact-us-box contact-us-right-box">
    <a href="https://facebook.com" target="_blank" class="contact-us-fb-link">
      <img src="./communityimage/icon19.png" alt="Facebook" class="contact-us-fb-icon">
    </a>
  </div>
</div>

</div>

</body>
</html>