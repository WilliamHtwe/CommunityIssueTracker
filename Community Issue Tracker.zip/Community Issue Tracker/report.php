<?php
session_start();
$is_logged_in = isset($_SESSION['user_id']);
require_once 'config.php';

$upload_dir = 'uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}
$message = '';
$messageType = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'success') {
        $message = "Report submitted successfully! Thank you for helping improve our community.";
        $messageType = "success";
    } elseif ($_GET['msg'] === 'error') {
        $message = "Error submitting report. Please try again.";
        $messageType = "error";
    }
        unset($_SESSION['report_data']);
}
if (isset($_GET['action']) && $_GET['action'] === 'get_cities' && isset($_GET['state'])) {
    header('Content-Type: application/json');
    $state = sanitize($_GET['state']);
    try {
        $stmt = $pdo->prepare("SELECT DISTINCT city FROM myanmar_locations WHERE state = ? ORDER BY city");
        $stmt->execute([$state]);
        $cities = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo json_encode(['success' => true, 'cities' => $cities]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Database error']);
    }
    exit;
}
$current_step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$validation_errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['report_data'] = $_SESSION['report_data'] ?? [];
    foreach ($_POST as $key => $value) {
        if ($key !== 'image') {
            $_SESSION['report_data'][$key] = sanitize($value);
        }
    }
    if ($current_step == 1) {
        if (empty($_POST['name'])) {
            $validation_errors[] = "Full name is required.";
        }
        if (empty($_POST['phone'])) {
            $validation_errors[] = "Phone number is required.";
        }
    } elseif ($current_step == 2) {
        if (empty($_POST['state'])) {
            $validation_errors[] = "Please select a state.";
        }
        if (empty($_POST['city'])) {
            $validation_errors[] = "Please select a city.";
        }
    } elseif ($current_step == 3) {
        if (empty($_POST['issue_type'])) {
            $validation_errors[] = "Please select an issue type.";
        }
        if (empty($_POST['concern_level'])) {
            $validation_errors[] = "Please select a concern level.";
        }
        if (empty($_POST['issue_description'])) {
            $validation_errors[] = "Issue description is required.";
        }
    }

    if (empty($validation_errors)) {
        if ($current_step == 5) {
            $user_id = $_SESSION['user_id'];
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM reports 
                                   WHERE user_id = ? 
                                   AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                                   AND YEAR(created_at) = YEAR(CURRENT_DATE())");
            $stmt->execute([$user_id]);
            $report_count = $stmt->fetchColumn();

            if ($report_count >= 1) {
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

                    <title>Report Limit</title>
                    <style>
                        body {
                            margin: 0;
                            font-family: 'Inter', sans-serif;
                        }
                        #overlay {
                            position: fixed;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                            background: rgba(0,0,0,0.6);
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            z-index: 9999;
                        }
                        .overlay-box {
                            background: #fff;
                            padding: 20px;
                            border-radius: 30px;
                            text-align: center;
                            width: 300px;
                        }
                        .overlay-box h2 {
                            color: #C63A41;
                            font-size: 24px;
                            line-height: 1;
                            margin-bottom: 16px;
                        }
                        .overlay-box p {
                            font-size: 16px;
                            margin: 0;
                            line-height: 1.5;
                            color: #0A0A0A;
                        }
                        .overlay-box button {
                            margin-top: 16px;
                            padding: 12px 24px;
                            border: none;
                            background: #C63A41;
                            color: #E5E7EB;
                            border-radius: 20px;
                            cursor: pointer;
                            font-size: 16px;
                        }
                        .overlay-box button:hover {
                            background: rgba(226, 69, 69, 1);
                        }
                    </style>
                </head>
                <body>
                    <div id="overlay">
                        <div class="overlay-box">
                            <h2>Report Limit Reached</h2>
                            <p>You have already submitted a report this month.<br>
                               You can only submit <strong>one report per month</strong>.</p>
                            <button onclick="window.location.href='home.php'">Go to Home Page</button>
                        </div>
                    </div>
                </body>
                </html>
                <?php
                exit;
            }

            // ✅ Proceed with normal report submission
            $image_path = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['image']['name'];
                $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

                if (in_array($file_ext, $allowed)) {
                    $new_filename = uniqid() . '.' . $file_ext;
                    $upload_path = $upload_dir . $new_filename;

                    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                        $image_path = $upload_path;
                    }
                }
            }
            $_SESSION['report_data']['image_path'] = $image_path;

            $data = $_SESSION['report_data'];
            $latitude = $data['latitude'] ? floatval($data['latitude']) : null;
            $longitude = $data['longitude'] ? floatval($data['longitude']) : null;

            try {
                $stmt = $pdo->prepare("INSERT INTO reports 
                    (user_id, name, phone, state, city, latitude, longitude, location_name, issue_description, concern_level, issue_type, image_path, status, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())");
                $stmt->execute([
                    $user_id,
                    $data['name'],
                    $data['phone'],
                    $data['state'],
                    $data['city'],
                    $latitude,
                    $longitude,
                    $data['location_name'],
                    $data['issue_description'],
                    $data['concern_level'],
                    $data['issue_type'],
                    $data['image_path']
                ]);
                header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=success');
                exit;
            } catch (PDOException $e) {
                header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=error');
                exit;
            }
        } else {
            header('Location: ' . $_SERVER['PHP_SELF'] . '?step=' . ($current_step + 1));
            exit;
        }
    } else {
        $message = implode('<br>', $validation_errors);
        $messageType = "error";
    }
}

$locations_stmt = $pdo->query("SELECT DISTINCT state FROM myanmar_locations ORDER BY state");
$states = $locations_stmt->fetchAll(PDO::FETCH_COLUMN);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Report Issue - Community Issue Tracker</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="styles.css" />

<style>

body {
    font-family: 'Inter', sans-serif;
        background-color: #F3F4F6;
    transition: background-color 0.3s ease;
}

.report-container {
    max-width: 100%;
    display: flex;
    flex-direction: column;
    padding: 40px 20px;
    box-sizing: border-box;
}



.form-group label {
    font-size: 16px;
    margin-bottom: 10px;
    display: block;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #2F2F3B;
    background-color: #E5E7EB;
    color: #0A0A0A;
    border-radius: 20px;
    transition: all 0.2s ease-in-out;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #0A0A0A;
   
}

.form-group textarea {
    min-height: 120px;
}

.scroll-picker-container {
    position: relative;
    height: 200px;
    background-color: #E5E7EB;
     border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
    border-radius: 30px;
    overflow: hidden;
    margin-bottom: 20px;
}

.scroll-picker {
    height: 100%;
    overflow-y: scroll;
    scroll-behavior: smooth;
    scroll-snap-type: y mandatory;
    position: relative;
    padding: 75px 0;
    -webkit-overflow-scrolling: touch;
}

.scroll-picker::-webkit-scrollbar {
    display: none;
}

.scroll-picker-item {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    scroll-snap-align: center;
    transition: all 0.3s ease;
    cursor: pointer;
    color: #5E5E69;
    user-select: none;
}

.scroll-picker-item.selected {
    color: #0A0A0A;
    transform: scale(1.1);
}

.scroll-picker-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    pointer-events: none;
    background: linear-gradient(
    to bottom,
    rgba(229, 231, 235, 1) 0%,
    rgba(229, 231, 235, 0.8) 20%,
    rgba(229, 231, 235, 0) 35%,
    rgba(229, 231, 235, 0) 65%,
    rgba(229, 231, 235, 0.8) 80%,
    rgba(229, 231, 235, 1) 100%
);
}

.scroll-picker-selection-line {
    position: absolute;
    top: 50%;
    left: 10px;
    right: 10px;
    height: 50px;
    transform: translateY(-50%);
    border-top: 1px solid #0A0A0A;
    border-bottom: 1px solid #0A0A0A;
    border-radius: 10px;
    pointer-events: none;
}

.btn-primary {
    width: 100%;
    padding: 12px 24px;
    background-color: #0A0A0A;
    color:#E5E7EB;
    border-radius:30px;
    border: none;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.btn-primary:hover {
    background-color: #1D1D24;
}

.btn-secondary {
    width: 100%;
    padding: 12px 24px;
    background-color: #E5E7EB;
    color: #0A0A0A;
    border-radius: 30px;
    border: none;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.btn-secondary:hover {
    background-color: #5E5E69;
    color: #E5E7EB;
}

.alert {
    padding: 1rem;
    margin-bottom: 1rem;
    border-radius: 0.5rem;
    font-weight: 500;
    opacity: 1;
    transition: opacity 0.5s ease-out;
}

.alert-success {
    background-color: #155724;
    color: #d4edda;
}

.alert-error {
    background-color: #721c24;
    color: #f8d7da;
}

.step-header {
    text-align: center;
    margin-bottom: 32px;
    color: #2F2F3B;
}

.step-header h2 {
    font-size: 24px;
    color: #0A0A0A;
}

.step-header p {
    color: #2F2F3B;
    font-size: 16px;
}

.step-navigation {
    display: flex;
    gap: 0.75rem;
}

.selection-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.selection-grid label {
    flex: 1 1 calc(50% - 20px); /* Two items per row on mobile */
    min-width: 140px;
}

.selection-grid input[type="radio"] {
    display: none;
}

.selection-grid span {
    display: block;
    padding: 12px;
    background-color: #E5E7EB;
font-size: 14px;
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
    border-radius: 30px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
}

.selection-grid input[type="radio"]:checked + span {
    background-color: #0A0A0A;
    color: #E5E7EB;
}

.file-input-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #E5E7EB;
    border-radius: 30px;
    height: 150px;
     color: #0A0A0A;
    cursor: pointer;
    transition: all 0.2s ease-in-out;
}
.file-input-wrapper:hover {
    background-color:#2F2F3B;
    color: #E5E7EB;
}
.file-input-text {
    font-size: 16px;
}

.file-selected {
    margin-top:10px;
    font-size: 16px;
    color: #0A0A0A;
}
.file-input-wrapper input[type="file"] {
    display: none;
}


</style>
</head>
 <div class ="body-maincontainer">
        <nav class="mobile-nav">
            <a href="home.php" class="nav-item">
                <img src="./communityimage/icon1.png" alt="Home">
                <span>Home</span>
            </a>
            <a href="report.php" class="nav-item">
                <img src="./communityimage/icon2.png" alt="Search">
                <span>Report</span>
            </a>
            <a href="aboutus.php" class="nav-item">
                <img src="./communityimage/icon3.png" alt="Alerts">
                <span>About Us</span>
            </a>
            <a href="contact.php" class="nav-item">
                <img src="./communityimage/icon4.png" alt="Profile">
                <span>Contact</span>
            </a>
            <a href="check_profile.php" class="nav-item">
                <img src="./communityimage/icon25.png" alt="Profile">
                <span>Profile</span>
            </a>
        </nav>
<body>
<div class="report-container">
    <div class="step-header">
        <?php if ($current_step == 1): ?>
            <p>Step 1 of 5</p>
            <h2>Your Information</h2>
        <?php elseif ($current_step == 2): ?>
            <p>Step 2 of 5</p>
            <h2>Issue Location</h2>
        <?php elseif ($current_step == 3): ?>
            <p>Step 3 of 5</p>
            <h2>Issue Details</h2>
        <?php elseif ($current_step == 4): ?>
            <p>Step 4 of 5</p>
            <h2>Mark on Map</h2>
        <?php elseif ($current_step == 5): ?>
            <p>Step 5 of 5</p>
            <h2>Upload an Image</h2>
        <?php endif; ?>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>" id="alert-message">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="main-form">
        <?php if ($current_step == 1): ?>
            <div id="step-1" class="form-step">
                <div class="form-group mb-6">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo $_SESSION['report_data']['name'] ?? ''; ?>" required />
                </div>
                <div class="form-group mb-6">
                    <label for="phone">Phone Number *</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo $_SESSION['report_data']['phone'] ?? ''; ?>" required />
                </div>
                <button type="submit" class="btn-primary">Next</button>
            </div>
        <?php elseif ($current_step == 2): ?>
            <div id="step-2" class="form-step">
                <div class="form-group mb-6">
                    <label for="state">State *</label>
                    <div class="scroll-picker-container">
                        <div class="scroll-picker" id="state-picker" data-name="state">
                            <div class="scroll-picker-item" data-value="">Select State</div>
                            <?php foreach ($states as $state): ?>
                                <div class="scroll-picker-item" data-value="<?php echo htmlspecialchars($state); ?>"
                                     <?php echo (isset($_SESSION['report_data']['state']) && $_SESSION['report_data']['state'] === $state) ? 'data-selected="true"' : ''; ?>>
                                    <?php echo htmlspecialchars($state); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="scroll-picker-overlay"></div>
                        <div class="scroll-picker-selection-line"></div>
                    </div>
                    <input type="hidden" id="state" name="state" value="<?php echo $_SESSION['report_data']['state'] ?? ''; ?>" required />
                    <div id="state-error" class="error-message" style="display: none;">Please select a state</div>
                </div>
                
                <div class="form-group mb-6">
                    <label for="city">City *</label>
                    <div class="scroll-picker-container">
                        <div class="scroll-picker" id="city-picker" data-name="city">
                            <div class="scroll-picker-item" data-value="">Select State first</div>
                        </div>
                        <div class="scroll-picker-overlay"></div>
                        <div class="scroll-picker-selection-line"></div>
                    </div>
                    <input type="hidden" id="city" name="city" value="<?php echo $_SESSION['report_data']['city'] ?? ''; ?>" required />
                    <div id="city-error" class="error-message" style="display: none;">Please select a city</div>
                </div>
                
                <div class="step-navigation">
                    <button type="button" class="btn-secondary" onclick="window.location.href='?step=1'">Previous</button>
                    <button type="button" id="step2-next" class="btn-primary">Next</button>
                </div>
            </div>
        <?php elseif ($current_step == 3): ?>
            <div id="step-3" class="form-step">
                <div class="form-group mb-6">
                    <label for="issue_type">Issue Type *</label>
                    <div class="selection-grid" id="issue-type-grid">
                        <label>
                            <input type="radio" name="issue_type" value="road" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'road') ? 'checked' : ''; ?> required>
                            <span>Road Issues</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="bridge" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'bridge') ? 'checked' : ''; ?>>
                            <span>Bridge Problems</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="water_supply" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'water_supply') ? 'checked' : ''; ?>>
                            <span>Water Supply</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="electricity" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'electricity') ? 'checked' : ''; ?>>
                            <span>Electricity</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="waste_management" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'waste_management') ? 'checked' : ''; ?>>
                            <span>Waste Management</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="street_lighting" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'street_lighting') ? 'checked' : ''; ?>>
                            <span>Street Lighting</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="drainage" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'drainage') ? 'checked' : ''; ?>>
                            <span>Drainage System</span>
                        </label>
                        <label>
                            <input type="radio" name="issue_type" value="other" <?php echo (isset($_SESSION['report_data']['issue_type']) && $_SESSION['report_data']['issue_type'] === 'other') ? 'checked' : ''; ?>>
                            <span>Other</span>
                        </label>
                    </div>
                    <div id="issue-type-error" class="error-message" style="display: none;">Please select an issue type</div>
                </div>
                <div class="form-group mb-6 mt-4">
                    <label for="concern_level">Concern Level *</label>
                    <div class="selection-grid" id="concern-level-grid">
                        <label>
                            <input type="radio" name="concern_level" value="low" <?php echo (isset($_SESSION['report_data']['concern_level']) && $_SESSION['report_data']['concern_level'] === 'low') ? 'checked' : ''; ?> required>
                            <span>Low</span>
                        </label>
                        <label>
                            <input type="radio" name="concern_level" value="medium" <?php echo (isset($_SESSION['report_data']['concern_level']) && $_SESSION['report_data']['concern_level'] === 'medium') ? 'checked' : ''; ?>>
                            <span>Medium</span>
                        </label>
                        <label>
                            <input type="radio" name="concern_level" value="high" <?php echo (isset($_SESSION['report_data']['concern_level']) && $_SESSION['report_data']['concern_level'] === 'high') ? 'checked' : ''; ?>>
                            <span>High</span>
                        </label>
                        <label>
                            <input type="radio" name="concern_level" value="critical" <?php echo (isset($_SESSION['report_data']['concern_level']) && $_SESSION['report_data']['concern_level'] === 'critical') ? 'checked' : ''; ?>>
                            <span>Critical</span>
                        </label>
                    </div>
                    <div id="concern-level-error" class="error-message" style="display: none;">Please select a concern level</div>
                </div>
                <div class="form-group mb-6">
                    <label for="issue_description">Issue Description *</label>
                    <textarea id="issue_description" name="issue_description" required placeholder="Please provide detailed description of the issue..."><?php echo $_SESSION['report_data']['issue_description'] ?? ''; ?></textarea>
                </div>
                <div class="step-navigation">
                    <button type="button" class="btn-secondary" onclick="window.location.href='?step=2'">Previous</button>
                    <button type="button" id="step3-next" class="btn-primary">Next</button>
                </div>
            </div>
        <?php elseif ($current_step == 4): ?>
            <div id="step-4" class="form-step">
                <div class="form-group mb-6">
                    <label for="map">Select Location on Map</label>
                    <p class="text-sm text-gray-500 mb-4">Use your current location or click on the map to select the exact location of the issue.</p>
                    <div id="location-status" class="location-status status-info mb-4 hidden"></div>
                    <div id="map" class="map-container rounded-lg" style="height: 350px;"></div>
                    <div class="location-controls mt-4">
                        <button type="button" id="get-location" class="btn-location">Use Current Location</button>
                        <button type="button" id="clear-location" class="btn-clear" style="display: none;">Clear Location</button>
                    </div>
                    <div id="location-info" class="location-info hidden">
                        <strong>Selected Location:</strong> <span id="location-text"></span>
                    </div>
                </div>
                <input type="hidden" id="latitude" name="latitude" value="<?php echo $_SESSION['report_data']['latitude'] ?? ''; ?>" />
                <input type="hidden" id="longitude" name="longitude" value="<?php echo $_SESSION['report_data']['longitude'] ?? ''; ?>" />
                <input type="hidden" id="location_name" name="location_name" value="<?php echo $_SESSION['report_data']['location_name'] ?? ''; ?>" />
                <div class="step-navigation">
                    <button type="button" class="btn-secondary" onclick="window.location.href='?step=3'">Previous</button>
                    <button type="submit" class="btn-primary">Next</button>
                </div>
            </div>
        <?php elseif ($current_step == 5): ?>
            <div id="step-5" class="form-step">
                <div class="form-group mb-6">
                    <label for="image">Upload Image (Optional)</label>
                    <div class="file-input-wrapper mb-2" onclick="document.getElementById('image').click()">
                        <div class="file-input-text" id="file-input-text">Choose File</div>
                        <input type="file" id="image" name="image" accept="image/*" />
                    </div>
                    <div id="file-selected" class="file-selected hidden"></div>
                </div>
                <div class="step-navigation">
                    <button type="button" class="btn-secondary" onclick="window.location.href='?step=4'">Previous</button>
                    <button type="submit" class="btn-primary">Submit Report</button>
                </div>
            </div>
        <?php endif; ?>
    </form>
</div>
        </div>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const alertMessage = document.getElementById('alert-message');
    if (alertMessage) {
        setTimeout(function() {
            alertMessage.style.transition = 'opacity 0.5s ease-out';
            alertMessage.style.opacity = '0';
            setTimeout(function() {
                alertMessage.style.display = 'none';
                if (window.history && window.history.replaceState) {
                    const url = new URL(window.location);
                    url.searchParams.delete('msg');
                    window.history.replaceState({}, document.title, url.toString());
                }
            }, 500);
        }, 4000);
    }

    initializeScrollPickers();
    
    initializeStepValidations();
});

function initializeStepValidations() {
    const step2NextBtn = document.getElementById('step2-next');
    if (step2NextBtn) {
        step2NextBtn.addEventListener('click', function() {
            if (validateStep2()) {
                document.getElementById('main-form').submit();
            }
        });
    }
    const step3NextBtn = document.getElementById('step3-next');
    if (step3NextBtn) {
        step3NextBtn.addEventListener('click', function() {
            if (validateStep3()) {
                document.getElementById('main-form').submit();
            }
        });
    }
}

function validateStep2() {
    let valid = true;
    const stateValue = document.getElementById('state').value;
    const cityValue = document.getElementById('city').value;
    
    if (!stateValue) {
        document.getElementById('state-error').style.display = 'block';
        document.getElementById('state-error').style.color = '#dc2626';
        document.getElementById('state-error').style.marginTop = '5px';
        document.getElementById('state-error').style.fontSize = '14px';
        valid = false;
    } else {
        document.getElementById('state-error').style.display = 'none';
    }
        if (!cityValue) {
        document.getElementById('city-error').style.display = 'block';
        document.getElementById('city-error').style.color = '#dc2626';
        document.getElementById('city-error').style.marginTop = '5px';
        document.getElementById('city-error').style.fontSize = '14px';
        valid = false;
    } else {
        document.getElementById('city-error').style.display = 'none';
    }
    
    return valid;
}

function validateStep3() {
    let valid = true;
        const issueTypeChecked = document.querySelector('input[name="issue_type"]:checked');
    if (!issueTypeChecked) {
        document.getElementById('issue-type-error').style.display = 'block';
        document.getElementById('issue-type-error').style.color = '#dc2626';
        document.getElementById('issue-type-error').style.marginTop = '5px';
        document.getElementById('issue-type-error').style.fontSize = '14px';
        valid = false;
    } else {
        document.getElementById('issue-type-error').style.display = 'none';
    }
        const concernLevelChecked = document.querySelector('input[name="concern_level"]:checked');
    if (!concernLevelChecked) {
        document.getElementById('concern-level-error').style.display = 'block';
        document.getElementById('concern-level-error').style.color = '#dc2626';
        document.getElementById('concern-level-error').style.marginTop = '5px';
        document.getElementById('concern-level-error').style.fontSize = '14px';
        valid = false;
    } else {
        document.getElementById('concern-level-error').style.display = 'none';
    }
        const description = document.getElementById('issue_description').value.trim();
    if (!description) {
        document.getElementById('issue_description').focus();
        valid = false;
    }
    
    return valid;
}

function addRealTimeValidation() {
    document.getElementById('state').addEventListener('change', function() {
        if (this.value) {
            document.getElementById('state-error').style.display = 'none';
        }
    });
    
    document.getElementById('city').addEventListener('change', function() {
        if (this.value) {
            document.getElementById('city-error').style.display = 'none';
        }
    });
    
    const issueTypeRadios = document.querySelectorAll('input[name="issue_type"]');
    issueTypeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            document.getElementById('issue-type-error').style.display = 'none';
        });
    });
    
    const concernLevelRadios = document.querySelectorAll('input[name="concern_level"]');
    concernLevelRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            document.getElementById('concern-level-error').style.display = 'none';
        });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    addRealTimeValidation();
});

function initializeScrollPickers() {
    const pickers = document.querySelectorAll('.scroll-picker');
    
    pickers.forEach(picker => {
        const items = picker.querySelectorAll('.scroll-picker-item');
        let isScrolling = false;
        let scrollTimeout;
        const selectedItem = picker.querySelector('[data-selected="true"]');
        if (selectedItem) {
            setTimeout(() => {
                selectedItem.scrollIntoView({ block: 'center', behavior: 'smooth' });
                updateSelection(picker, selectedItem);
            }, 100);
        }
        picker.addEventListener('scroll', function() {
            if (!isScrolling) {
                isScrolling = true;
            }

            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                isScrolling = false;
                snapToNearestItem(picker);
            }, 150);

            updateVisibleSelection(picker);
        });
        items.forEach(item => {
            item.addEventListener('click', function() {
                this.scrollIntoView({ block: 'center', behavior: 'smooth' });
                setTimeout(() => {
                    updateSelection(picker, this);
                }, 300);
            });
        });

        let startY = 0;
        picker.addEventListener('touchstart', function(e) {
            startY = e.touches[0].clientY;
        });

        picker.addEventListener('touchend', function(e) {
            const endY = e.changedTouches[0].clientY;
            const diff = startY - endY;
            
            if (Math.abs(diff) < 5) { 
                const rect = picker.getBoundingClientRect();
                const centerY = rect.top + rect.height / 2;
                const targetItem = findNearestItem(picker, centerY);
                if (targetItem) {
                    targetItem.scrollIntoView({ block: 'center', behavior: 'smooth' });
                    setTimeout(() => {
                        updateSelection(picker, targetItem);
                    }, 300);
                }
            }
        });
    });
}

function updateVisibleSelection(picker) {
    const items = picker.querySelectorAll('.scroll-picker-item');
    const rect = picker.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;

    let nearestItem = null;
    let minDistance = Infinity;

    items.forEach(item => {
        const itemRect = item.getBoundingClientRect();
        const itemCenterY = itemRect.top + itemRect.height / 2;
        const distance = Math.abs(centerY - itemCenterY);

        if (distance < minDistance) {
            minDistance = distance;
            nearestItem = item;
        }
    });
    items.forEach(item => {
        item.classList.remove('selected');
    });

    if (nearestItem) {
        nearestItem.classList.add('selected');
    }
}

function snapToNearestItem(picker) {
    const rect = picker.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    const nearestItem = findNearestItem(picker, centerY);
    
    if (nearestItem) {
        nearestItem.scrollIntoView({ block: 'center', behavior: 'smooth' });
        setTimeout(() => {
            updateSelection(picker, nearestItem);
        }, 300);
    }
}

function findNearestItem(picker, centerY) {
    const items = picker.querySelectorAll('.scroll-picker-item');
    let nearestItem = null;
    let minDistance = Infinity;

    items.forEach(item => {
        const itemRect = item.getBoundingClientRect();
        const itemCenterY = itemRect.top + itemRect.height / 2;
        const distance = Math.abs(centerY - itemCenterY);

        if (distance < minDistance) {
            minDistance = distance;
            nearestItem = item;
        }
    });

    return nearestItem;
}

function updateSelection(picker, selectedItem) {
    const items = picker.querySelectorAll('.scroll-picker-item');
    const pickerName = picker.getAttribute('data-name');
    const hiddenInput = document.getElementById(pickerName);
    items.forEach(item => {
        item.classList.remove('selected');
    });
    selectedItem.classList.add('selected');
    if (hiddenInput) {
        hiddenInput.value = selectedItem.getAttribute('data-value');
        hiddenInput.dispatchEvent(new Event('change'));
    }
    if (pickerName === 'state') {
        const stateValue = selectedItem.getAttribute('data-value');
        if (stateValue) {
            loadCitiesForState(stateValue);
        } else {
            resetCityPicker();
        }
    }
}

function loadCitiesForState(state) {
    const cityPicker = document.getElementById('city-picker');
    const cityInput = document.getElementById('city');
    cityPicker.innerHTML = '<div class="scroll-picker-item" data-value="">Loading cities...</div>';
    fetch(`?action=get_cities&state=${encodeURIComponent(state)}`)
        .then(response => response.json())
        .then(data => {
            let html = '<div class="scroll-picker-item" data-value="">Select City</div>';
            
            if (data.success && data.cities.length > 0) {
                data.cities.forEach(city => {
                    const selectedAttr = (cityInput.value === city) ? ' data-selected="true"' : '';
                    html += `<div class="scroll-picker-item" data-value="${city}"${selectedAttr}>${city}</div>`;
                });
            } else {
                html = '<div class="scroll-picker-item" data-value="">No cities found</div>';
            }
            cityPicker.innerHTML = html;
            initializeSinglePicker(cityPicker);
            const selectedCity = cityPicker.querySelector('[data-selected="true"]');
            if (selectedCity) {
                setTimeout(() => {
                    selectedCity.scrollIntoView({ block: 'center', behavior: 'smooth' });
                    updateSelection(cityPicker, selectedCity);
                }, 100);
            }
        })
        .catch(error => {
            console.error('Error fetching cities:', error);
            cityPicker.innerHTML = '<div class="scroll-picker-item" data-value="">Error loading cities</div>';
        });
}
function resetCityPicker() {
    const cityPicker = document.getElementById('city-picker');
    const cityInput = document.getElementById('city');
    
    cityPicker.innerHTML = '<div class="scroll-picker-item" data-value="">Select State first</div>';
    cityInput.value = '';
}
function initializeSinglePicker(picker) {
    const items = picker.querySelectorAll('.scroll-picker-item');
    let isScrolling = false;
    let scrollTimeout;
    picker.addEventListener('scroll', function() {
        if (!isScrolling) {
            isScrolling = true;
        }

        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            isScrolling = false;
            snapToNearestItem(picker);
        }, 150);

        updateVisibleSelection(picker);
    });
    items.forEach(item => {
        item.addEventListener('click', function() {
            this.scrollIntoView({ block: 'center', behavior: 'smooth' });
            setTimeout(() => {
                updateSelection(picker, this);
            }, 300);
        });
    });
}
const fileInput = document.getElementById('image');
if (fileInput) {
    fileInput.addEventListener('change', function() {
        const fileText = document.getElementById('file-input-text');
        const fileSelected = document.getElementById('file-selected');

        if (this.files && this.files[0]) {
            const fileName = this.files[0].name;
            const fileSize = (this.files[0].size / 1024 / 1024).toFixed(2); // MB

            fileText.textContent = 'File Selected';
            fileSelected.textContent = `${fileName} (${fileSize} MB)`;
            fileSelected.classList.remove('hidden');
        } else {
            fileText.textContent = 'Choose File';
            fileSelected.classList.add('hidden');
        }
    });
}
const mapElement = document.getElementById('map');
if (mapElement) {
    var map = L.map('map').setView([19.7633, 96.0785], 6);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var marker = null;
    var currentLocationMarker = null;
    var accuracyCircle = null;
    map.on('click', function(e) {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;

        if (marker) {
            map.removeLayer(marker);
        }
        if (currentLocationMarker) {
            map.removeLayer(currentLocationMarker);
            currentLocationMarker = null;
        }
        if (accuracyCircle) {
            map.removeLayer(accuracyCircle);
            accuracyCircle = null;
        }

        marker = L.marker([lat, lng])
            .addTo(map)
            .bindPopup('Selected Location')
            .openPopup();

        updateLocationInfo(lat, lng, false);
    });
    document.getElementById('clear-location').addEventListener('click', function() {
        if (marker) {
            map.removeLayer(marker);
            marker = null;
        }
        if (currentLocationMarker) {
            map.removeLayer(currentLocationMarker);
            currentLocationMarker = null;
        }
        if (accuracyCircle) {
            map.removeLayer(accuracyCircle);
            accuracyCircle = null;
        }
        document.getElementById('latitude').value = '';
        document.getElementById('longitude').value = '';
        document.getElementById('location_name').value = '';
        document.getElementById('location-info').classList.add('hidden');
        document.getElementById('location-status').classList.add('hidden');
        this.style.display = 'none';

        map.setView([19.7633, 96.0785], 6);
    });
    function updateLocationInfo(lat, lng, isCurrent, accuracy) {
        document.getElementById('latitude').value = lat.toFixed(8);
        document.getElementById('longitude').value = lng.toFixed(8);
        var info = `${lat.toFixed(8)}, ${lng.toFixed(8)}`;
        if (isCurrent && accuracy) {
            info += ` (Current Location - ±${Math.round(accuracy)}m)`;
        }
        document.getElementById('location_name').value = info;
        document.getElementById('location-text').innerText = info;
        document.getElementById('location-info').classList.remove('hidden');
        document.getElementById('clear-location').style.display = 'inline-block';
    }

    function showStatus(msg, type) {
        var status = document.getElementById('location-status');
        status.textContent = msg;
        status.className = `location-status status-${type}`;
        status.classList.remove('hidden');
    }

    document.getElementById('get-location').addEventListener('click', function () {
        var button = this;
        if (!navigator.geolocation) {
            showStatus('Geolocation is not supported by this browser.', 'error');
            return;
        }
        button.disabled = true;
        let attempts = 0;
        const maxAttempts = 15;
        let bestPos = null;
        showStatus('Trying to get your location with high accuracy...', 'info');
        function tryGetPosition() {
            navigator.geolocation.getCurrentPosition(
                function (pos) {
                    attempts++;
                    var lat = pos.coords.latitude;
                    var lng = pos.coords.longitude;
                    var acc = pos.coords.accuracy;

                    if (!bestPos || acc < bestPos.coords.accuracy) {
                        bestPos = pos;
                    }

                    if (acc <= 15) {
                        acceptLocation(lat, lng, acc);
                        return;
                    } else if (acc <= 100) {
                        showStatus(`Accuracy ±${Math.round(acc)}m. Trying to improve... (Attempt ${attempts}/${maxAttempts})`, 'info');
                        updateTemporaryMarker(lat, lng, acc);
                        if (attempts < maxAttempts) {
                            setTimeout(tryGetPosition, 1500);
                        } else {
                            acceptLocation(bestPos.coords.latitude, bestPos.coords.longitude, bestPos.coords.accuracy);
                            showStatus(`Max attempts reached. Using best accuracy ±${Math.round(bestPos.coords.accuracy)}m`, 'warning');
                        }
                    } else {
                        showStatus(`Accuracy ±${Math.round(acc)}m too low, retrying... (Attempt ${attempts}/${maxAttempts})`, 'info');
                        if (attempts < maxAttempts) {
                            setTimeout(tryGetPosition, 1500);
                        } else {
                            if (bestPos) {
                                acceptLocation(bestPos.coords.latitude, bestPos.coords.longitude, bestPos.coords.accuracy);
                                showStatus(`Max attempts reached. Using best accuracy ±${Math.round(bestPos.coords.accuracy)}m`, 'warning');
                            } else {
                                showStatus('Unable to get good location. Please try in an open area.', 'error');
                            }
                            button.disabled = false;
                        }
                    }
                },
                function (err) {
                    showStatus('Error getting location: ' + err.message, 'error');
                    button.disabled = false;
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        }
        function updateTemporaryMarker(lat, lng, acc) {
            if (currentLocationMarker) {
                map.removeLayer(currentLocationMarker);
                if (accuracyCircle) map.removeLayer(accuracyCircle);
            }
            if (marker) {
                map.removeLayer(marker);
                marker = null;
            }
            accuracyCircle = L.circle([lat, lng], {
                radius: acc,
                color: '#3B82F6',
                fillOpacity: 0.1,
            }).addTo(map);
            currentLocationMarker = L.marker([lat, lng])
                .addTo(map)
                .bindPopup(`Temporary Location<br>Accuracy: ±${Math.round(acc)}m`)
                .openPopup();
            map.setView([lat, lng], 16);
        }
        function acceptLocation(lat, lng, acc) {
            if (currentLocationMarker) {
                map.removeLayer(currentLocationMarker);
                if (accuracyCircle) map.removeLayer(accuracyCircle);
            }
            if (marker) {
                map.removeLayer(marker);
                marker = null;
            }
            accuracyCircle = L.circle([lat, lng], {
                radius: acc,
                color: '#3B82F6',
                fillOpacity: 0.15,
            }).addTo(map);
            currentLocationMarker = L.marker([lat, lng])
                .addTo(map)
                .bindPopup(`Your Location<br>Accuracy: ±${Math.round(acc)}m`)
                .openPopup();
            map.setView([lat, lng], 18);
            updateLocationInfo(lat, lng, true, acc);
            showStatus(`Location fixed with accuracy ±${Math.round(acc)}m!`, 'success');

            button.disabled = false;
        }
        tryGetPosition();
    });
    const existingLat = document.getElementById('latitude').value;
    const existingLng = document.getElementById('longitude').value;
    if (existingLat && existingLng) {
        updateLocationInfo(parseFloat(existingLat), parseFloat(existingLng), false);
        map.setView([existingLat, existingLng], 16);
        marker = L.marker([existingLat, existingLng])
            .addTo(map)
            .bindPopup('Previously Selected Location')
            .openPopup();
    }
}
 // A PHP variable is used to communicate login status to JavaScript
    const isLoggedIn = <?php echo json_encode($is_logged_in); ?>;

    // The URL to redirect to for non-registered users
    const loginUrl = 'login_user.php';

    // Get the form container
    const reportContainer = document.querySelector('.report-container');

    if (!isLoggedIn && reportContainer) {
        // Add a click listener to the entire report form container
        reportContainer.addEventListener('click', function(event) {
            const target = event.target;
            
            // Check if the user clicked on an input, button, or selection grid
            const isInteractive = target.tagName === 'INPUT' || 
                                  target.tagName === 'BUTTON' || 
                                  target.closest('.selection-grid') || 
                                  target.closest('.scroll-picker-container');
            
            if (isInteractive) {
                // Prevent the default action (like opening a dropdown or focusing an input)
                event.preventDefault();
                event.stopPropagation();
                
                // Redirect to the login page
                window.location.href = loginUrl;
            }
        });
    }
</script>
</body>
</html>