<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit();
}

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_phone'])) {
    $new_phone = trim($_POST['new_phone']);
    
    if (empty($new_phone)) {
        $error = 'Phone number is required';
    } elseif (!preg_match('/^09\d{8,9}$/', $new_phone)) {
        $error = 'Please enter a valid phone number (09xxxxxxxx or 09xxxxxxxxx)';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE phone_number = ? AND id != ?");
            $stmt->execute([$new_phone, $_SESSION['user_id']]);
            
            if ($stmt->fetch()) {
                $error = 'This phone number is already registered to another account';
            } else {
                $stmt = $pdo->prepare("UPDATE users SET phone_number = ? WHERE id = ?");
                if ($stmt->execute([$new_phone, $_SESSION['user_id']])) {
                    $_SESSION['phone_number'] = $new_phone;
                    $success = 'Phone number updated successfully';
                } else {
                    $error = 'Failed to update phone number. Please try again.';
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error. Please try again.';
        }
    }
}

try {
    $stmt = $pdo->prepare("SELECT first_name, last_name, phone_number, nrc_number, created_at, points FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user) {
        session_destroy();
        header("Location: login_user.php");
        exit();
    }
} catch (PDOException $e) {
    $error = 'Error loading profile. Please try again.';
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM reports 
                       WHERE user_id = ? 
                       AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                       AND YEAR(created_at) = YEAR(CURRENT_DATE())");
$stmt->execute([$_SESSION['user_id']]);
$report_count = $stmt->fetchColumn();

$remaining_chances = 1 - $report_count;
if ($remaining_chances < 0) $remaining_chances = 0;
try {
    $stmt = $pdo->prepare("SELECT status, concern_level, issue_type, city, state, created_at 
                           FROM reports 
                           WHERE user_id = ? 
                           ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $user_reports = $stmt->fetchAll();
} catch (PDOException $e) {
    $user_reports = [];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Community Issue Tracker</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
    <style>
      .profile-container {
            max-width: none;
            width: 100%;
            margin: 0;
            padding: 40px 20px;
            background: none;
            border: none;
            box-shadow: none;
        }
        
       .profile-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
}

.profile-title {
    font-size: 24px;
    line-height: 24px;
    color: #0A0A0A;
    margin: 0;
}

.logout-btn {
    padding: 12px 24px;
    background-color: #C63A41;
    color: #E5E7EB;
    text-decoration: none;
    border: none;
    border-radius: 30px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin-top: 0; 
    width: auto;   
}

.logout-btn:hover {
    background: rgba(204, 49, 65, 1);
}

        .profile-info {
            margin-bottom: 32px;
        }
        
        .info-group {
            margin-bottom: 24px;
            padding: 20px;
            border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
            background: #E5E7EB;
            border-radius: 30px;
            position: relative;
        }
        
        .info-label {
            color: #0A0A0A;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .info-value {
            font-size: 20px;
            color: #0A0A0A;
        }
        
        .phone-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .edit-btn {
            background: #0A0A0A;
            color: #E5E7EB;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        
        .edit-btn:hover {
            background: #1D1D24;
        }
        
        .edit-form {
            display: none;
            margin-top: 5px;
        }
        
        .form-input {
            width: 100%;
            padding: 10px;
            border: 2px solid #1D1D24;
            border-radius: 20px;
            font-size: 16px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #0A0A0A;
        }
        
        .form-buttons {
            display: flex;
            gap: 15px;
        }
        
        .save-btn {
            padding: 10px 20px;
    background-color: #0A0A0A;
    color:#E5E7EB;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;

        }
        
        .cancel-btn {
            background-color: #C63A41;
    color: #0A0A0A;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
        }
        
 
        
        .success-message {
                        background: #E5E7EB;

            color: #2E966B;
            padding: 10px;
            border-radius: 20px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
        
        .error-message {
                        background: #E5E7EB;

            color: #C63A41;
            padding: 10px;
            border-radius: 20px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }
        .reports-section {
    margin: 0;
}

.reports-title {
    font-size: 24px;
    line-height: 1;
    margin-top: 0;
    margin-bottom: 32px;
    color: #0A0A0A;
}

.reports-scroll {
    display: flex;
    gap: 20px;
    overflow-x: auto;
    padding-bottom: 10px;
    scrollbar-width: thin;
    scrollbar-color: #0A0A0A #E5E7EB;
}

.reports-scroll::-webkit-scrollbar {
    height: 8px;
}

.reports-scroll::-webkit-scrollbar-track {
    background: #E5E7EB;
    border-radius: 10px;
}

.reports-scroll::-webkit-scrollbar-thumb {
    background-color: #0A0A0A;
    border-radius: 10px;
}

.report-card {
    flex: 0 0 auto;
    width: 350px;
    background: #E5E7EB;
    border-radius: 30px;
     padding: 20px;
  border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
    color: #0A0A0A;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.report-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.report-label {
    font-size: 14px;
    font-weight: bold;
    color: #0A0A0A;
    flex: 1;
    line-height: 1.5;
}

.report-value {
    text-align: right;
    flex: 1;
    text-transform: uppercase;
    font-size: 14px;
    line-height: 1.5;
    color: #0A0A0A;
}

.leaderboard-link {
    position: absolute;
    top: 20px;
    right: 20px;
    background: #0A0A0A;
    color: #E5E7EB;
    text-decoration: none;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 12px;
    transition: background-color 0.3s;
}

.leaderboard-link:hover {
    background: #1D1D24;
}

    </style>
</head>
<body>
    <div class="body-maincontainer">
        <nav class="mobile-nav">
            <a href="home.php" class="nav-item">
                <img src="./communityimage/icon1.png" alt="Home">
                <span>Home</span>
            </a>
            <a href="report.php" class="nav-item">
                <img src="./communityimage/icon2.png" alt="Search">
                <span>Report</span>
            </a>
            <a href="aboutus.php" class="nav-item">
                <img src="./communityimage/icon3.png" alt="Alerts">
                <span>About Us</span>
            </a>
            <a href="contact.php" class="nav-item">
                <img src="./communityimage/icon4.png" alt="Profile">
                <span>Contact</span>
            </a>
            <a href="check_profile.php" class="nav-item">
                <img src="./communityimage/icon25.png" alt="Profile">
                <span>Profile</span>
            </a>
        </nav>

        <div class="profile-container">
           <div class="profile-header">
    <h1 class="profile-title">Profile</h1>
    <a href="logout_user.php" class="logout-btn" onclick="return confirm('Are you sure you want to logout?')">Logout</a>
</div>

            
            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <div class="profile-info">
                <div class="info-group">
                    <div class="info-label">Name</div>
                    <div class="info-value"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></div>
                </div>
                
                <div class="info-group">
                    <div class="info-label">Phone Number</div>
                    <div class="phone-group">
                        <div class="info-value" id="phone-display"><?php echo htmlspecialchars($user['phone_number']); ?></div>
                        <button type="button" class="edit-btn" onclick="togglePhoneEdit()">Edit</button>
                    </div>
                    
                    <form method="POST" action="" class="edit-form" id="phone-edit-form">
                        <input 
                            type="text" 
                            name="new_phone" 
                            class="form-input" 
                            placeholder="09xxxxxxxx (10-11 digits)"
                            value="<?php echo htmlspecialchars($user['phone_number']); ?>"
                            id="new_phone_input"
                            required
                        >
                        <div class="form-buttons">
                            <button type="submit" name="update_phone" class="save-btn">Save</button>
                            <button type="button" class="cancel-btn" onclick="cancelPhoneEdit()">Cancel</button>
                        </div>
                    </form>
                </div>
                
                <div class="info-group">
                    <div class="info-label">NRC Number</div>
                    <div class="info-value"><?php echo htmlspecialchars($user['nrc_number']); ?></div>
                </div>
                
                <div class="info-group">
                    <div class="info-label">Member Since</div>
                    <div class="info-value"><?php echo date('F j, Y', strtotime($user['created_at'])); ?></div>
                </div>
                
                <div class="info-group">
                    <div class="info-label">Report Chances Left This Month</div>
                    <div class="info-value"><?php echo $remaining_chances; ?></div>
                </div>
                
                <div class="info-group">
                    <div class="info-label">Total Points</div>
                    <div class="info-value"><?php echo htmlspecialchars($user['points'] ?? 0); ?></div>
                    <a href="leaderboard.php" class="leaderboard-link">View Leaderboard</a>
                </div>
            </div>
            
            <div class="reports-section">
                <h2 class="reports-title">Report History</h2>
                <div class="reports-scroll">
                    <?php if (empty($user_reports)): ?>
                        <p class="no-reports">No reports submitted yet.</p>
                    <?php else: ?>
                        <?php foreach ($user_reports as $report): ?>
                            <div class="report-card">
                                <div class="report-row">
                                    <span class="report-label">Status</span>
                                    <span class="report-value"><?php echo htmlspecialchars($report['status']); ?></span>
                                </div>
                                <div class="report-row">
                                    <span class="report-label">Concern</span>
                                    <span class="report-value"><?php echo htmlspecialchars($report['concern_level']); ?></span>
                                </div>
                                <div class="report-row">
                                    <span class="report-label">Issue</span>
                                    <span class="report-value"><?php echo htmlspecialchars($report['issue_type']); ?></span>
                                </div>
                                <div class="report-row">
                                    <span class="report-label">City</span>
                                    <span class="report-value"><?php echo htmlspecialchars($report['city']); ?></span>
                                </div>
                                <div class="report-row">
                                    <span class="report-label">State</span>
                                    <span class="report-value"><?php echo htmlspecialchars($report['state']); ?></span>
                                </div>
                                <div class="report-row">
                                    <span class="report-label">Date</span>
                                    <span class="report-value"><?php echo date('M j, Y', strtotime($report['created_at'])); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

    <script>
        function togglePhoneEdit() {
            const editForm = document.getElementById('phone-edit-form');
            const phoneDisplay = document.getElementById('phone-display');
            const editBtn = document.querySelector('.edit-btn');
            
            if (editForm.style.display === 'none' || editForm.style.display === '') {
                editForm.style.display = 'block';
                phoneDisplay.style.display = 'none';
                editBtn.style.display = 'none';
            }
        }
        
        function cancelPhoneEdit() {
            const editForm = document.getElementById('phone-edit-form');
            const phoneDisplay = document.getElementById('phone-display');
            const editBtn = document.querySelector('.edit-btn');
            const phoneInput = document.getElementById('new_phone_input');
            
            editForm.style.display = 'none';
            phoneDisplay.style.display = 'block';
            editBtn.style.display = 'block';
            phoneInput.value = phoneDisplay.textContent;
        }
        
        document.getElementById('new_phone_input').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
            if (value.length > 11) {
                value = value.slice(0, 11); 
            }
            if (value.length >= 2 && !value.startsWith('09')) {
                if (value.startsWith('9')) {
                    value = '0' + value;
                } else if (value.length <= 9) {
                    value = '09' + value;
                }
            }
            e.target.value = value;
        });
    </script>
</body>
</html>