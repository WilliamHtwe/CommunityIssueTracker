<?php
session_start();
require_once 'config.php';

$error = '';
$success = '';

if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'missing_fields':
            $error = 'First name and last name are required';
            break;
        case 'phone_required':
            $error = 'Phone number is required';
            break;
        case 'invalid_phone':
            $error = 'Please enter a valid phone number (09xxxxxxxx or 09xxxxxxxxx)';
            break;
        case 'password_required':
            $error = 'Password is required';
            break;
        case 'password_short':
            $error = 'Password must be at least 6 characters long';
            break;
        case 'password_mismatch':
            $error = 'Passwords do not match';
            break;
        case 'nrc_required':
            $error = 'NRC number is required';
            break;
        case 'invalid_nrc':
            $error = 'Please enter a valid NRC number (e.g., 12/MaYaKa(N)123456)';
            break;
        case 'phone_exists':
            $error = 'Phone number already registered. Please login instead.';
            break;
        case 'nrc_exists':
            $error = 'NRC number already registered. Please login instead.';
            break;
        case 'registration_failed':
            $error = 'Registration failed. Please try again.';
            break;
        case 'database_error':
            $error = 'Database error. Please try again.';
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST)) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone_number = trim($_POST['phone_number']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $nrc_number = trim($_POST['nrc_number']);
    
    if (empty($first_name) || empty($last_name)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=missing_fields");
        exit();
    } elseif (empty($phone_number)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=phone_required");
        exit();
    } elseif (!preg_match('/^09\d{8,9}$/', $phone_number)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=invalid_phone");
        exit();
    } elseif (empty($password)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=password_required");
        exit();
    } elseif (strlen($password) < 6) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=password_short");
        exit();
    } elseif ($password !== $confirm_password) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=password_mismatch");
        exit();
    } elseif (empty($nrc_number)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=nrc_required");
        exit();
    } elseif (!preg_match('/^\d{1,2}\/[A-Za-z]+\([A-Za-z]\)\d{6}$/', $nrc_number)) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?error=invalid_nrc");
        exit();
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE phone_number = ?");
            $stmt->execute([$phone_number]);
            
            if ($stmt->fetch()) {
                header("Location: " . $_SERVER['PHP_SELF'] . "?error=phone_exists");
                exit();
            } else {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE nrc_number = ?");
                $stmt->execute([$nrc_number]);
                
                if ($stmt->fetch()) {
                    header("Location: " . $_SERVER['PHP_SELF'] . "?error=nrc_exists");
                    exit();
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    
                    $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, phone_number, password, nrc_number, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                    
                    if ($stmt->execute([$first_name, $last_name, $phone_number, $hashed_password, $nrc_number])) {
                        $user_id = $pdo->lastInsertId();
                        
                        $_SESSION['user_id'] = $user_id;
                        $_SESSION['user_name'] = $first_name . ' ' . $last_name;
                        $_SESSION['phone_number'] = $phone_number;
                        
                        header("Location: profile.php");
                        exit();
                    } else {
                        header("Location: " . $_SERVER['PHP_SELF'] . "?error=registration_failed");
                        exit();
                    }
                }
            }
        } catch (PDOException $e) {
            header("Location: " . $_SERVER['PHP_SELF'] . "?error=database_error");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Community Issue Tracker</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
<style>
    .register-container {
        max-width: 500px;
        margin: 0px auto;
        padding:20px;
        overflow: hidden;
        position: relative;
    }

    .form-header {
        padding:20px;
        text-align: center;
    }

    .step-counter {
        color: #0A0A0A;
        font-size: 14px;
        margin-bottom: 10px;
    }
    
    .register-title {
        font-size: 24px;
        color: #0A0A0A;
        line-height: 24px;
        margin-bottom: 16px;
    }

    .form-subtitle {
        color: #0A0A0A;
        font-size: 16px;
        line-height: 1.5;
        margin: 0;
    }

    .form-content {
        padding: 0px;
        min-height: 200px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .step {
        display: none;
    }

    .step.active {
        display: block;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 10px;
        color: #0A0A0A;
        font-size: 16px;
    } 
    .form-input {
        width: 100%;
        padding: 12px 24px;
        border: 1px solid #2F2F3B;
        background-color: #E5E7EB;
        color: #0A0A0A;
        border-radius: 20px;
        font-size: 16px;
        transition: all 0.3s ease;
        background: #FAFAFA;
        box-sizing: border-box;
    }
    
    .form-input:focus {
        outline: none;
        border: 1px solid #2F2F3B;
    }
    
    .form-input.error {
        border-color: #dc3545;
        background: #FEF2F2;
    }
    
    .register-btn {
        width: 100%;
        padding: 12px 24px;
        background-color: #0A0A0A;
        color:#E5E7EB;
        border: none;
        border-radius: 30px;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .register-btn:hover {
            background-color: #1D1D24;

    }

    .register-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
    }

    .btn-secondary {
        width: 100%;
        padding: 12px 24px;
        background: #F9FAFB;
        color: #6B7280;
        border: 2px solid #E5E7EB;
        border-radius: 30px;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .btn-secondary:hover {
        background: #F3F4F6;
        border-color: #D1D5DB;
    }
    
    .error-message {
        background: #FEF2F2;
        color: #DC2626;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 20px;
        border: 1px solid #FECACA;
        font-size: 14px;
    }
    
    .login-link {
        text-align: center;
        margin-top: 20px;
        padding-top: 20px;
    }
    
    .login-link a {
        color: #4590E6;
        text-decoration: none;
        font-weight: 500;
    }
    
    .login-link a:hover {
        text-decoration: underline;
    }
    
    .form-helper {
        font-size: 14px;
        color: #6B7280;
        margin-top: 8px;
        line-height: 1.4;
    }

   .button-group {
        display: flex;
        flex-direction: row;
        gap: 10px;
        margin-top: 20px;
    }
    .completion-screen {
        text-align: center;
        padding: 60px 40px;
    }

    .success-icon {
        width: 80px;
        height: 80px;
            background-color: #0A0A0A; 

        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 24px;
    }

    .success-title {
        font-size: 24px;
        font-weight: 700;
        color: #1a1a1a;
        margin-bottom: 12px;
    }

    .success-subtitle {
        color: #6B7280;
        font-size: 16px;
        margin-bottom: 32px;
    }


</style>
</head>
<body>
    <div class="body-maincontainer">
        <nav class="mobile-nav">
            <a href="home.php" class="nav-item">
                <img src="./communityimage/icon1.png" alt="Home">
                <span>Home</span>
            </a>
            <a href="report.php" class="nav-item">
                <img src="./communityimage/icon2.png" alt="Search">
                <span>Report</span>
            </a>
            <a href="aboutus.php" class="nav-item">
                <img src="./communityimage/icon3.png" alt="Alerts">
                <span>About Us</span>
            </a>
            <a href="contact.php" class="nav-item">
                <img src="./communityimage/icon4.png" alt="Profile">
                <span>Contact</span>
            </a>
            <a href="check_profile.php" class="nav-item">
                <img src="./communityimage/icon25.png" alt="Profile">
                <span>Profile</span>
            </a>
        </nav>

        <div class="register-container">
            <div class="form-header">
                <div class="step-counter" id="stepCounter">Step 1 of 4</div>
                <h1 class="register-title" id="formTitle">What's your full name?</h1>
                <p class="form-subtitle" id="formSubtitle">Let's start with the basics</p>
            </div>

            <div class="form-content">
                <div id="errorContainer">
                    <?php if ($error): ?>
                        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                </div>

                <form method="POST" action="" id="registrationForm">
                    <div class="step active" data-step="1">
                        <div class="form-group">
                            <label for="first_name" class="form-label">First Name</label>
                            <input 
                                type="text" 
                                id="first_name" 
                                name="first_name" 
                                class="form-input" 
                                placeholder="Enter your first name"
                                autocomplete="given-name"
                            >
                        </div>
                        <div class="form-group">
                            <label for="last_name" class="form-label">Last Name</label>
                            <input 
                                type="text" 
                                id="last_name" 
                                name="last_name" 
                                class="form-input" 
                                placeholder="Enter your last name"
                                autocomplete="family-name"
                            >
                        </div>
                    </div>

                    <div class="step" data-step="2">
                        <div class="form-group">
                            <label for="phone_number" class="form-label">Phone Number</label>
                            <input 
                                type="tel" 
                                id="phone_number" 
                                name="phone_number" 
                                class="form-input" 
                                placeholder="09xxxxxxxx"
                                autocomplete="tel"
                            >
                            <div class="form-helper">Format: 09xxxxxxxx (10-11 digits starting with 09)</div>
                        </div>
                    </div>

                    <div class="step" data-step="3">
                        <div class="form-group">
                            <label for="password" class="form-label">Password</label>
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                class="form-input" 
                                placeholder="Enter your password"
                                autocomplete="new-password"
                            >
                            <div class="form-helper">Choose a password with at least 6 characters</div>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input 
                                type="password" 
                                id="confirm_password" 
                                name="confirm_password" 
                                class="form-input" 
                                placeholder="Confirm your password"
                                autocomplete="new-password"
                            >
                        </div>
                    </div>

                    <div class="step" data-step="4">
                        <div class="form-group">
                            <label for="nrc_number" class="form-label">NRC Number</label>
                            <input 
                                type="text" 
                                id="nrc_number" 
                                name="nrc_number" 
                                class="form-input" 
                                placeholder="12/MaYaKa(N)123456"
                            >
                            <div class="form-helper">Format: State/Township(Type)Number (e.g., 12/MaYaKa(N)123456)</div>
                        </div>
                    </div>

                    <input type="hidden" name="step_first_name" id="step_first_name">
                    <input type="hidden" name="step_last_name" id="step_last_name">
                    <input type="hidden" name="step_phone_number" id="step_phone_number">
                    <input type="hidden" name="step_password" id="step_password">
                    <input type="hidden" name="step_confirm_password" id="step_confirm_password">
                    <input type="hidden" name="step_nrc_number" id="step_nrc_number">
                </form>

                <div class="button-group">
                    <button type="button" class="btn-secondary" id="prevBtn" style="display: none;">
                        Back
                    </button>
                    <button type="button" class="register-btn" id="nextBtn">
                        Continue
                    </button>
                </div>

                <div class="login-link">
                    <p>Already have an account? <a href="login_user.php">Login here</a></p>
                </div>
            </div>

            <div id="completionScreen" class="completion-screen" style="display: none;">
                <div class="success-icon"> 
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
        <path d="M20 6L9 17L4 12" stroke="#E5E7EB" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</div>

                <h2 class="success-title">Ready to Register!</h2>
                <p class="success-subtitle">All information looks good. Click below to complete your registration.</p>
                <button type="button" class="register-btn" onclick="submitForm()">
                    Complete Registration
                </button>
            </div>
        </div>
    </div>

    <script>
        class MultiStepForm {
            constructor() {
                this.currentStep = 1;
                this.totalSteps = 4; 
                this.formData = {};
                
                this.init();
            }

            init() {
                this.bindEvents();
                this.updateStepContent();
                this.focusCurrentInput();
            }

            bindEvents() {
                const nextBtn = document.getElementById('nextBtn');
                const prevBtn = document.getElementById('prevBtn');

                nextBtn.addEventListener('click', () => this.nextStep());
                prevBtn.addEventListener('click', () => this.prevStep());

                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' && this.currentStep <= this.totalSteps) {
                        e.preventDefault();
                        this.nextStep();
                    }
                });
                const phoneInput = document.getElementById('phone_number');
                phoneInput.addEventListener('input', (e) => {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length > 11) {
                        value = value.slice(0, 11);
                    }
                    if (value.length >= 2 && !value.startsWith('09')) {
                        if (value.startsWith('9')) {
                            value = '0' + value;
                        } else if (value.length <= 9) {
                            value = '09' + value;
                        }
                    }
                    e.target.value = value;
                });

                const confirmPasswordInput = document.getElementById('confirm_password');
                confirmPasswordInput.addEventListener('input', () => {
                    this.validatePasswordMatch();
                });

                const passwordInput = document.getElementById('password');
                passwordInput.addEventListener('input', () => {
                    this.validatePasswordMatch();
                });
            }

            validatePasswordMatch() {
                const passwordInput = document.getElementById('password');
                const confirmPasswordInput = document.getElementById('confirm_password');
                
                if (confirmPasswordInput.value && passwordInput.value !== confirmPasswordInput.value) {
                    confirmPasswordInput.classList.add('error');
                } else {
                    confirmPasswordInput.classList.remove('error');
                }
            }

            nextStep() {
                if (this.validateCurrentStep()) {
                    this.saveCurrentStepData();
                    
                    if (this.currentStep === this.totalSteps) {
                        this.showCompletion();
                    } else {
                        this.currentStep++;
                        this.updateStep();
                    }
                }
            }

            prevStep() {
                if (this.currentStep > 1) {
                    this.currentStep--;
                    this.updateStep();
                }
            }

            updateStep() {
                this.hideAllSteps();
                this.showCurrentStep();
                this.updateStepContent();
                this.updateButtons();
                this.focusCurrentInput();
                this.clearErrors();
            }

            hideAllSteps() {
                document.querySelectorAll('.step').forEach(step => {
                    step.classList.remove('active');
                });
            }

            showCurrentStep() {
                const currentStepElement = document.querySelector(`[data-step="${this.currentStep}"]`);
                if (currentStepElement) {
                    currentStepElement.classList.add('active');
                }
            }

            updateStepContent() {
                const stepData = {
                    1: {
                        counter: "Step 1 of 4",
                        title: "What's your full name?",
                        subtitle: "Let's start with the basics"
                    },
                    2: {
                        counter: "Step 2 of 4",
                        title: "What's your phone number?",
                        subtitle: "We'll use this for account verification"
                    },
                    3: {
                        counter: "Step 3 of 4",
                        title: "Create your password",
                        subtitle: "Keep your account secure"
                    },
                    4: {
                        counter: "Step 4 of 4",
                        title: "What's your NRC number?",
                        subtitle: "Required for account verification"
                    }
                };

                const data = stepData[this.currentStep];
                document.getElementById('stepCounter').textContent = data.counter;
                document.getElementById('formTitle').textContent = data.title;
                document.getElementById('formSubtitle').textContent = data.subtitle;
            }

            updateButtons() {
                const nextBtn = document.getElementById('nextBtn');
                const prevBtn = document.getElementById('prevBtn');

                prevBtn.style.display = this.currentStep === 1 ? 'none' : 'block';
                nextBtn.textContent = this.currentStep === this.totalSteps ? 'Review & Complete' : 'Continue';
            }

            focusCurrentInput() {
                setTimeout(() => {
                    const currentStep = document.querySelector(`[data-step="${this.currentStep}"]`);
                    const input = currentStep?.querySelector('input');
                    if (input) {
                        input.focus();
                    }
                }, 100);
            }

            validateCurrentStep() {
                const currentStepElement = document.querySelector(`[data-step="${this.currentStep}"]`);
                if (!currentStepElement) return false;

                let isValid = true;
                let errorMessage = '';

                currentStepElement.querySelectorAll('.form-input').forEach(input => {
                    input.classList.remove('error');
                });

                switch (this.currentStep) {
                    case 1: 
                        const firstNameInput = document.getElementById('first_name');
                        const lastNameInput = document.getElementById('last_name');
                        if (!firstNameInput.value.trim() || !lastNameInput.value.trim()) {
                            errorMessage = 'First name and last name are required';
                            isValid = false;
                            if (!firstNameInput.value.trim()) firstNameInput.classList.add('error');
                            if (!lastNameInput.value.trim()) lastNameInput.classList.add('error');
                        }
                        break;

                    case 2: 
                        const phoneInput = document.getElementById('phone_number');
                        const phoneValue = phoneInput.value.trim();
                        if (!phoneValue) {
                            errorMessage = 'Phone number is required';
                            isValid = false;
                        } else if (!/^09\d{8,9}$/.test(phoneValue)) {
                            errorMessage = 'Please enter a valid phone number (09xxxxxxxx or 09xxxxxxxxx)';
                            isValid = false;
                        }
                        if (!isValid) phoneInput.classList.add('error');
                        break;

                    case 3: 
                        const passwordInput = document.getElementById('password');
                        const confirmPasswordInput = document.getElementById('confirm_password');
                        const passwordValue = passwordInput.value.trim();
                        const confirmPasswordValue = confirmPasswordInput.value.trim();
                        
                        if (!passwordValue) {
                            errorMessage = 'Password is required';
                            isValid = false;
                            passwordInput.classList.add('error');
                        } else if (passwordValue.length < 6) {
                            errorMessage = 'Password must be at least 6 characters long';
                            isValid = false;
                            passwordInput.classList.add('error');
                        } else if (!confirmPasswordValue) {
                            errorMessage = 'Please confirm your password';
                            isValid = false;
                            confirmPasswordInput.classList.add('error');
                        } else if (passwordValue !== confirmPasswordValue) {
                            errorMessage = 'Passwords do not match';
                            isValid = false;
                            confirmPasswordInput.classList.add('error');
                        }
                        break;

                    case 4: 
                        const nrcInput = document.getElementById('nrc_number');
                        const nrcValue = nrcInput.value.trim();
                        if (!nrcValue) {
                            errorMessage = 'NRC number is required';
                            isValid = false;
                        } else if (!/^\d{1,2}\/[A-Za-z]+\([A-Za-z]\)\d{6}$/.test(nrcValue)) {
                            errorMessage = 'Please enter a valid NRC number format (e.g., 12/MaYaKa(N)123456)';
                            isValid = false;
                        }
                        if (!isValid) nrcInput.classList.add('error');
                        break;
                }

                if (!isValid) {
                    this.showError(errorMessage);
                }

                return isValid;
            }

            saveCurrentStepData() {
                const currentInputs = document.querySelectorAll(`[data-step="${this.currentStep}"] input`);
                currentInputs.forEach(input => {
                    this.formData[input.name] = input.value.trim();
                });
            }

            showError(message) {
                const errorContainer = document.getElementById('errorContainer');
                errorContainer.innerHTML = `<div class="error-message">${message}</div>`;
                setTimeout(() => {
                    if (!errorContainer.querySelector('.error-message')?.textContent.includes('already registered')) {
                        errorContainer.innerHTML = '';
                    }
                }, 5000);
            }

            clearErrors() {
                const errorContainer = document.getElementById('errorContainer');
                if (!errorContainer.textContent.includes('already registered')) {
                    errorContainer.innerHTML = '';
                }
            }

            showCompletion() {
                document.querySelector('.form-header').style.display = 'none';
                document.querySelector('.form-content').style.display = 'none';
                document.getElementById('completionScreen').style.display = 'block';
            }
        }

        function submitForm() {
            const form = document.getElementById('registrationForm');
            const multiStepForm = window.multiStepForm;
                        Object.keys(multiStepForm.formData).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = multiStepForm.formData[key];
                }
            });
                        form.submit();
        }

        document.addEventListener('DOMContentLoaded', () => {
            window.multiStepForm = new MultiStepForm();
            
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
                        window.addEventListener('popstate', function(event) {
                if (event.state) {
                    window.location.reload();
                }
            });
            
            // Clear form on page load to prevent cached values
            setTimeout(() => {
                const form = document.getElementById('registrationForm');
                if (form && !window.location.search.includes('error=')) {
                    form.reset();
                    // Reset the multi-step form to step 1
                    if (window.multiStepForm) {
                        window.multiStepForm.currentStep = 1;
                        window.multiStepForm.formData = {};
                        window.multiStepForm.updateStep();
                    }
                }
            }, 100);
        });
    </script>
</body>
</html>