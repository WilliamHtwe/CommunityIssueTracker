<?php
session_start();
require_once 'config.php';
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $phone_number = trim($_POST['phone_number']);
    $password = $_POST['password'];
        if (empty($phone_number)) {
        $error = 'Phone number is required';
    } elseif (empty($password)) {
        $error = 'Password is required';
    } elseif (!preg_match('/^09\d{8,9}$/', $phone_number)) {
        $error = 'Please enter a valid phone number (09xxxxxxxx or 09xxxxxxxxx)';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, first_name, last_name, password FROM users WHERE phone_number = ?");
            $stmt->execute([$phone_number]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
                $_SESSION['phone_number'] = $phone_number;
                
                header("Location: profile.php");
                exit();
            } else {
                $error = 'Invalid phone number or password.';
            }
        } catch (PDOException $e) {
            $error = 'Database error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Community Issue Tracker</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
    <style>
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }
        
        .login-container {
            width: calc(100% - 40px); 
            max-width: 500px;
            background: #E5E7EB;
            padding: 20px;
            border-radius: 30px;
            border: 1px solid rgba(0, 0, 0, 0.03);
            box-shadow:
            0 2px 4px rgba(0, 0, 0, 0.04),
            0 4px 8px rgba(0, 0, 0, 0.03);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        .login-title {
            text-align: center;
            font-size: 24px;
            line-height: 24px;
            margin-bottom: 32px;
            color: #0A0A0A;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            color: #0A0A0A;
        }
        
        .form-input {
            width: 100%;
            padding: 12px 24px;
            border: 1px solid #2F2F3B;
            background-color: #E5E7EB;
            color: #0A0A0A;
            border-radius: 20px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #0A0A0A;
        }
        
        .login-btn {
            width: 100%;
            padding: 12px 24px;
            background-color: #0A0A0A;
            color:#E5E7EB;
            border-radius:30px;
            border: none;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .login-btn:hover {
            background-color: #1D1D24;
        }
        
        .error-message {
    background-color: #F3F4F6;
            color: #C63A41;
            padding: 10px;
            border-radius: 20px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }
        
        .register-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .register-link a {
            color: #4590E6;
            text-decoration: none;
        }
        
        .register-link a:hover {
            text-decoration: underline;
        }

        
    </style>
</head>
<body>
      <div class ="body-maincontainer">
    <div class="login-container">
        <h1 class="login-title">Login</h1>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="phone_number" class="form-label">Phone Number</label>
                <input 
                    type="text" 
                    id="phone_number" 
                    name="phone_number" 
                    class="form-input" 
                    placeholder="09xxxxxxxx"
                    value="<?php echo isset($_POST['phone_number']) ? htmlspecialchars($_POST['phone_number']) : ''; ?>"
                    required
                >
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    class="form-input" 
                    placeholder="Enter your password"
                    required
                >
            </div>
            
            <button type="submit" class="login-btn">Login</button>
        </form>
        
        <div class="register-link">
            <p>Don't have an account? <a href="register_user.php">Register here</a></p>
        </div>
    </div>

    <!-- Moved mobile navigation outside the login container for better layout separation -->
    <nav class="mobile-nav">
        <a href="home.php" class="nav-item">
            <img src="./communityimage/icon1.png" alt="Home">
            <span>Home</span>
        </a>
        <a href="report.php" class="nav-item">
            <img src="./communityimage/icon2.png" alt="Search">
            <span>Report</span>
        </a>
        <a href="aboutus.php" class="nav-item">
            <img src="./communityimage/icon3.png" alt="Alerts">
            <span>About Us</span>
        </a>
        <a href="contact.php" class="nav-item">
            <img src="./communityimage/icon4.png" alt="Profile">
            <span>Contact</span>
        </a>
        <a href="check_profile.php" class="nav-item">
            <img src="./communityimage/icon25.png" alt="Profile">
            <span>Profile</span>
        </a>
    </nav>
    </div>
</body>
</html>
