<?php
session_start();
require_once 'config.php';
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    header("Location: profile.php");
    exit();
} else {
    header("Location: login_user.php");
    exit();
}
?>