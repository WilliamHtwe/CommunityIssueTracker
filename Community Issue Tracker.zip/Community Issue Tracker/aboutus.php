<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Issue Tracker </title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class ="body-maincontainer">
        <nav class="mobile-nav">
            <a href="home.php" class="nav-item">
                <img src="./communityimage/icon1.png" alt="Home">
                <span>Home</span>
            </a>
            <a href="report.php" class="nav-item">
                <img src="./communityimage/icon2.png" alt="Search">
                <span>Report</span>
            </a>
            <a href="aboutus.php" class="nav-item">
                <img src="./communityimage/icon3.png" alt="Alerts">
                <span>About Us</span>
            </a>
            <a href="contact.php" class="nav-item">
                <img src="./communityimage/icon4.png" alt="Profile">
                <span>Contact</span>
            </a>
            <a href="check_profile.php" class="nav-item">
                <img src="./communityimage/icon25.png" alt="Profile">
                <span>Profile</span>
            </a>
        </nav>
<section class="about-hero">
  <h1>Building Stronger <br> <span>Communities</span> Together</h1>
  <p>
    We bridge the gap between residents and local government. 
    Every report gets heard, every issue gets tracked, 
    and every community gets stronger.
  </p>
</section>
<div class="benefits-section">
  <h2>Benefits for You</h2>
  <div class="benefits-container">
    
    <div class="benefit-box">
      <div class="icon">
        <img src="./communityimage/icon21.png" alt="Transparent Tracking">
      </div>
      <div class="text">Accountability</div>
    </div>
    
    <div class="benefit-box">
      <div class="icon">
        <img src="./communityimage/icon22.png" alt="Faster Response">
      </div>
      <div class="text">Faster Response</div>
    </div>
    
    <div class="benefit-box">
      <div class="icon">
        <img src="./communityimage/icon23.png" alt="Community Trust">
      </div>
      <div class="text">Easy to Use</div>
    </div>
    
    <div class="benefit-box">
      <div class="icon">
        <img src="./communityimage/icon24.png" alt="Direct Channel">
      </div>
      <div class="text">Mobile Friendly</div>
    </div>
    
  </div>
</div>

<div class="who-we-are-section">
  <h2>Who We Are</h2>
  <p>
    This platform is managed by the ministry of construction myanmar, this platform improves transparency, responsiveness, and community collaboration.
  </p>
</div>
<section class="reporters-section">
  <div class="reporters-box">
    <div class="profile-icons">
      <img src="./communityimage/image1.jpg" alt="Profile 1">
      <img src="./communityimage/image2.jpg" alt="Profile 2">
      <img src="./communityimage/image3.jpg" alt="Profile 3">
      <img src="./communityimage/image4.jpg" alt="Profile 4">
    </div>
    <div class="reporters-info">
      <div class="reporters-text">
        <span>New Monthly</span>
        <span>Reporters</span>
      </div>
      <div class="reporters-count">+500</div>
    </div>
  </div>
</section>

</div>
</body>
</html>