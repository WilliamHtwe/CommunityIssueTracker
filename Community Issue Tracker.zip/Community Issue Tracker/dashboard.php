<?php
session_start();
require_once 'config.php';
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
if (isset($_SESSION['admin_id'])) {
    $stmt = $pdo->prepare("UPDATE admin_users SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status']) && isset($_POST['report_id']) && isset($_POST['new_status'])) {
        $report_id = intval($_POST['report_id']);
        $new_status = $_POST['new_status'];

        $allowed_statuses = ['pending', 'under_review', 'confirmed', 'declined', 'finished'];
        if (in_array($new_status, $allowed_statuses)) {
            $stmt = $pdo->prepare("UPDATE reports SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            if ($stmt->execute([$new_status, $report_id])) {
                $_SESSION['success_message'] = "Report status updated successfully!";
            } else {
                $_SESSION['error_message'] = "Failed to update report status.";
            }
        }
    }
    if (isset($_POST['delete_report']) && isset($_POST['report_id'])) {
        $report_id = intval($_POST['report_id']);

        $stmt = $pdo->prepare("SELECT image_path FROM reports WHERE id = ?");
        $stmt->execute([$report_id]);
        $report = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($report && $report['image_path'] && file_exists($report['image_path'])) {
            unlink($report['image_path']);
        }

        $stmt = $pdo->prepare("DELETE FROM reports WHERE id = ?");
        if ($stmt->execute([$report_id])) {
            $_SESSION['success_message'] = "Report deleted successfully!";
        } else {
            $_SESSION['error_message'] = "Failed to delete report.";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$issue_type_filter = isset($_GET['issue_type']) ? $_GET['issue_type'] : '';
$concern_level_filter = isset($_GET['concern_level']) ? $_GET['concern_level'] : '';
$state_filter = isset($_GET['state']) ? $_GET['state'] : '';
$city_filter = isset($_GET['city']) ? $_GET['city'] : '';

$where_conditions = [];
$params = [];

if (!empty($status_filter)) {
    $where_conditions[] = "status = ?";
    $params[] = $status_filter;
}

if (!empty($issue_type_filter)) {
    $where_conditions[] = "issue_type = ?";
    $params[] = $issue_type_filter;
}

if (!empty($concern_level_filter)) {
    $where_conditions[] = "concern_level = ?";
    $params[] = $concern_level_filter;
}

if (!empty($state_filter)) {
    $where_conditions[] = "state = ?";
    $params[] = $state_filter;
}

if (!empty($city_filter)) {
    $where_conditions[] = "city = ?";
    $params[] = $city_filter;
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) FROM reports $where_clause";
$stmt = $pdo->prepare($count_query);
$stmt->execute($params);
$total_reports = $stmt->fetchColumn();
$total_pages = ceil($total_reports / $per_page);

$query = "SELECT * FROM reports $where_clause ORDER BY created_at DESC LIMIT $per_page OFFSET $offset";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stats_query = "SELECT 
    status,
    COUNT(*) as count,
    concern_level,
    issue_type,
    state
FROM reports 
GROUP BY status, concern_level, issue_type, state";
$stmt = $pdo->query($stats_query);
$stats_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

$status_stats = [];
$concern_stats = [];
$issue_type_stats = [];
$state_stats = [];

foreach ($stats_data as $stat) {
    if (!isset($status_stats[$stat['status']])) {
        $status_stats[$stat['status']] = 0;
    }
    $status_stats[$stat['status']] += $stat['count'];

    if (!isset($concern_stats[$stat['concern_level']])) {
        $concern_stats[$stat['concern_level']] = 0;
    }
    $concern_stats[$stat['concern_level']] += $stat['count'];

    if (!isset($issue_type_stats[$stat['issue_type']])) {
        $issue_type_stats[$stat['issue_type']] = 0;
    }
    $issue_type_stats[$stat['issue_type']] += $stat['count'];

    if (!isset($state_stats[$stat['state']])) {
        $state_stats[$stat['state']] = 0;
    }
    $state_stats[$stat['state']] += $stat['count'];
}
$states_query = "SELECT DISTINCT state FROM myanmar_locations ORDER BY state";
$states = $pdo->query($states_query)->fetchAll(PDO::FETCH_COLUMN);

$cities = [];
if (!empty($state_filter)) {
    $cities_query = "SELECT DISTINCT city FROM myanmar_locations WHERE state = ? ORDER BY city";
    $stmt = $pdo->prepare($cities_query);
    $stmt->execute([$state_filter]);
    $cities = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

if (!empty($_SESSION['success_message'])) {
    echo '<div class="alert success">' . $_SESSION['success_message'] . '</div>';
    unset($_SESSION['success_message']);
}
if (!empty($_SESSION['error_message'])) {
    echo '<div class="alert error">' . $_SESSION['error_message'] . '</div>';
    unset($_SESSION['error_message']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Community Tracker</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #F3F4F6;
            color: #0A0A0A;
            min-height: 100vh;
            line-height: 1.5;
        }

    .layout {
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 220px;
    background-color: #0A0A0A;
    color: #E5E7EB;
    padding: 40px 20px;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
}

.sidebar h2 {
    font-size: 24px;
    line-height: 1;
    margin: 0 0 40px 0;
    text-transform: uppercase;
    text-align: left;
}

.sidebar ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar ul li {
    margin-bottom: 20px;
}

.sidebar ul li a {
    color: #E5E7EB;
    text-decoration: none;
    font-size: 16px;
    display: block;
    padding: 10px 0; 
}


.main-content {
    margin-left: 220px; 
    flex: 1;
    padding: 20px 40px;
    background: #F3F4F6;
}

        .alert {
            padding: 12px 24px;
            border-radius: 5px;
            margin-bottom: 30px;
            border: 1px solid transparent;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
            border-color: rgba(16, 185, 129, 0.2);
        }

        .alert-error {
            background: rgba(220, 38, 38, 0.1);
            color: #DC2626;
            border-color: rgba(220, 38, 38, 0.2);
        }
        .stats-row {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 30px;
            margin-bottom: 30px;
        }

        .stats-row .bento-box {
            background: #E5E7EB;
            color: #0A0A0A;
            border-radius: 30px;
            padding: 10px;
                  border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);;

            transition: all 0.3s ease;
        }


   .charts-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); 
    grid-auto-rows: auto;
    gap: 30px;
    margin-bottom: 30px;
}


        .charts-grid .bento-box {
            background:#E5E7EB;
            border-radius: 30px;
            padding: 30px;
             border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
        }

        .charts-grid .bento-box.wide {
            grid-column: span 2;
        }

        .charts-grid .bento-box.tall {
            grid-row: span 2;
        }

       .stat-card {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start; 
    height: 150px; 
    padding: 10px; 
}

.stat-number {
    font-size: 24px;
                color: #0A0A0A;

    margin: 0;
    margin-bottom: 0; 
    display: block;
}

.stat-label {
                color: #0A0A0A;

    text-transform: uppercase;
    font-size: 14px;
    text-align: left; 
}
        .chart-container {
            position: relative;
            height: 400px;
            margin-top: 20px;
        }

        .chart-title {
            font-size: 24px;
                color: #0A0A0A;
            margin-bottom: 15px;
            text-transform: uppercase;
            text-align: left;
        }

       .filters {
            background: #E5E7EB;
    padding: 25px;
    border-radius: 30px;
    margin-bottom: 30px;
      border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
}

.filter-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 30px;
    margin-bottom: 30px;
}

.filter-group {
    display: flex;
    flex-direction: column;
}

.filter-group label {
    margin-bottom: 10px;
                    color: #0A0A0A;

    font-size: 24px;
    text-transform: uppercase;
}

.filter-group select {
    padding: 12px 24px;
    font-family: 'Inter', sans-serif;
    border: 1px solid #E5E7EB;
    border-radius: 5px;
    font-size: 14px;
    background: #0A0A0A;
    color: #E5E7EB;
}

.filter-group select option {
       background: #0A0A0A;

    border-radius: 30px;
    font-family: 'Inter', sans-serif;
    color: #E5E7EB;
}

.filter-btn {
    background:#0A0A0A;
    color: #E5E7EB;
    padding: 12px 24px;
    border: 2px solid #0A0A0A;
    border-radius: 30px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.3s ease;
     box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
}

.filter-btn:hover {
    border: 2px solid #0A0A0A;
    color: #0A0A0A;
    background-color: #E5E7EB;
     box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
}

.reports-section {
    margin-top: 50px;
}

.reports-section h2 {
    color: #0A0A0A;
    margin-bottom: 30px;
    font-size: 24px;
    text-transform: uppercase;
}

.report-card {
    border-radius:30px;
    padding: 30px;
    margin-bottom: 30px;
    background: #E5E7EB;
}

.report-header {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 20px;
}

.report-info-with-badges {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.report-info-with-badges h3 {
    margin: 0;
    color: #0A0A0A;
    font-size: 24px;
    white-space: nowrap;
}

.badges-inline {
    display: flex;
    align-items: center;
    gap: 10px;
}

.report-meta {
    font-size: 14px;
    color: #0A0A0A;
    margin-top: 4px;
}

.report-info h3 {
    color: #0A0A0A;
    font-size: 24px;
    margin-bottom: 10px;
}

.status-badge {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 16px;
    text-transform: uppercase;
}

.status-pending { background: #FBBF24; color: #0A192F; }
.status-under_review { background: #38BDF8; color: #0A192F; }
.status-confirmed { background: #10B981; color: #E2E8F0; }
.status-declined { background: #DC2626; color: #E2E8F0; }
.status-finished { background: #1E293B; color:#E2E8F0; }

.concern-badge {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 16px;
    text-transform: uppercase;
}

.concern-low { background: #FCA5A5; color: #7F1D1D; }
.concern-medium { background: #F87171; color: #7F1D1D; }
.concern-high { background: #DC2626; color: #E2E8F0; }
.concern-critical { background: #B91C1C; color: #E2E8F0; }

.report-content {
    display: grid;
    grid-template-columns: 1fr 1fr; 
    gap: 0; 
    margin-bottom: 20px;
    align-items: stretch; 
    border-radius: 5px;
    overflow: hidden; 
}

.report-details {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
}

.report-details p {
    margin-bottom: 16px;
    color:#0A0A0A;
}

.report-details strong {
    color: #0A0A0A;
    text-transform: uppercase;
    font-size: 16px;
}

.report-content > div:last-child,
.report-image-section {
    background: #E5E7EB;
    padding: 0; 
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    overflow: hidden; 
}

.report-image {
    width: 100%; 
    height: 100%; 
    border-radius: 20px;
    max-width: none;
    min-height: none; 
    object-fit: cover; 
    cursor: pointer;
    display: block;
}

.no-image-placeholder {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    background: #CBD5E1;
    color: #64748B;
    font-size: 16px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.no-image-placeholder p {
    margin: 0;
}


.report-actions {
    display: flex;
    gap: 15px;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 20px;
    padding-top: 20px; 
}

.status-select {
    padding: 12px 24px;
    border: 1px solid #0A0A0A;
    border-radius: 30px;
    font-size: 16px;
    background: #0A0A0A;
    color: #E5E7EB;
}

.status-select option {
    background: #0A0A0A;
    color: #E5E7EB;
}

.update-btn {
    background: #0A0A0A;
    color: #E5E7EB;
    padding: 12px 24px;
    border: 2px solid #0A0A0A;
    border-radius: 30px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.3s ease;
}

.update-btn:hover {
    border: 2px solid #0A0A0A;
    color: #0A0A0A;
    background-color: #E5E7EB;
}

.delete-btn {
    background: #C63A41;
    color: #E5E7EB;
    padding: 12px 24px;
    border: 2px solid #C63A41;
    border-radius: 30px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.3s ease;
}

.delete-btn:hover {
    border: 2px solid #C63A41;
    background-color: #E5E7EB;
    color: #C63A41;
}

.coordinates {
    background: rgba(226, 232, 240, 0.1);
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 16px;
    color:  #C63A41;
}

.coordinates + a {
    color: #C63A41;
    text-decoration: none;
    margin-left: 5px;
}

.coordinates + a:hover {
    text-decoration: underline;
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: 32px;
    flex-wrap: wrap;
}

.pagination a,
.pagination span {
    padding: 12px 12px;
    border: 2px solid #0A0A0A;
    border-radius: 20px;
    text-decoration: none;
    color: #0A0A0A;
    transition: all 0.3s ease;
    min-width: 50px;
    text-align: center;
}

.pagination a:hover {
    background: #0A0A0A;
    color:#E5E7EB ;
    border-color: #0A0A0A;
}

.pagination .current {
   background: #0A0A0A;
    color:#E5E7EB;
    border-color:#0A0A0A;
}
.chart-loading {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 200px;
    color: #94A3B8;
}
    </style>
</head>
<body>
     <div class="layout">
      <nav class="sidebar">
    <h2>Admin</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="reportreward.php">Reward</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

        <main class="main-content">

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        <div class="stats-row">
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo array_sum($status_stats); ?></span>
                    <div class="stat-label">Total Reports</div>
                </div>
            </div>
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_stats['pending'] ?? 0; ?></span>
                    <div class="stat-label">Pending</div>
                </div>
            </div>
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_stats['under_review'] ?? 0; ?></span>
                    <div class="stat-label">Under Review</div>
                </div>
            </div>
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_stats['confirmed'] ?? 0; ?></span>
                    <div class="stat-label">Confirmed</div>
                </div>
            </div>
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_stats['declined'] ?? 0; ?></span>
                    <div class="stat-label">Declined</div>
                </div>
            </div>
            <div class="bento-box">
                <div class="stat-card">
                    <span class="stat-number"><?php echo $status_stats['finished'] ?? 0; ?></span>
                    <div class="stat-label">Finished</div>
                </div>
            </div>
        </div>
        <div class="charts-grid">
        <div class="bento-box">
        <div class="chart-title">Status Distribution</div>
        <div class="chart-container">
            <canvas id="statusChart"></canvas>
        </div>
        </div>
        <div class="bento-box">
        <div class="chart-title">Issue Types</div>
        <div class="chart-container">
            <canvas id="issueChart"></canvas>
        </div>
        </div>
        <div class="bento-box wide">
        <div class="chart-title">Concern Levels</div>
        <div class="chart-container">
            <canvas id="concernChart"></canvas>
        </div>
            </div>
        <div class="bento-box wide">
        <div class="chart-title">Reports by State</div>
        <div class="chart-container">
            <canvas id="stateChart"></canvas>
        </div>
        </div>
        </div>
        <div class="filters">
            <form method="GET" action="">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="under_review" <?php echo $status_filter === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                            <option value="confirmed" <?php echo $status_filter === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="declined" <?php echo $status_filter === 'declined' ? 'selected' : ''; ?>>Declined</option>
                            <option value="finished" <?php echo $status_filter === 'finished' ? 'selected' : ''; ?>>Finished</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Issue Type</label>
                        <select name="issue_type">
                            <option value="">All Types</option>
                            <option value="road" <?php echo $issue_type_filter === 'road' ? 'selected' : ''; ?>>Road</option>
                            <option value="bridge" <?php echo $issue_type_filter === 'bridge' ? 'selected' : ''; ?>>Bridge</option>
                            <option value="water_supply" <?php echo $issue_type_filter === 'water_supply' ? 'selected' : ''; ?>>Water Supply</option>
                            <option value="electricity" <?php echo $issue_type_filter === 'electricity' ? 'selected' : ''; ?>>Electricity</option>
                            <option value="waste_management" <?php echo $issue_type_filter === 'waste_management' ? 'selected' : ''; ?>>Waste Management</option>
                            <option value="street_lighting" <?php echo $issue_type_filter === 'street_lighting' ? 'selected' : ''; ?>>Street Lighting</option>
                            <option value="drainage" <?php echo $issue_type_filter === 'drainage' ? 'selected' : ''; ?>>Drainage</option>
                            <option value="other" <?php echo $issue_type_filter === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Concern Level</label>
                        <select name="concern_level">
                            <option value="">All Levels</option>
                            <option value="low" <?php echo $concern_level_filter === 'low' ? 'selected' : ''; ?>>Low</option>
                            <option value="medium" <?php echo $concern_level_filter === 'medium' ? 'selected' : ''; ?>>Medium</option>
                            <option value="high" <?php echo $concern_level_filter === 'high' ? 'selected' : ''; ?>>High</option>
                            <option value="critical" <?php echo $concern_level_filter === 'critical' ? 'selected' : ''; ?>>Critical</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>State</label>
                        <select name="state" id="stateSelect" onchange="loadCities(this.value)">
                            <option value="">All States</option>
                            <?php foreach ($states as $state): ?>
                                <option value="<?php echo htmlspecialchars($state); ?>" <?php echo $state_filter === $state ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($state); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>City</label>
                        <select name="city" id="citySelect">
                            <option value="">All Cities</option>
                            <?php foreach ($cities as $city): ?>
                                <option value="<?php echo htmlspecialchars($city); ?>" <?php echo $city_filter === $city ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($city); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="filter-btn">Apply Filters</button>
            </form>
        </div>

      <div class="reports-section">

        <h2>Reports ( <?php echo $total_reports; ?> total )</h2>

        <?php if (empty($reports)): ?>
        <p style="text-align: center; color: #E2E8F0; margin: 30px 0; font-size: 24px;">No reports found matching your criteria.</p>
        <?php else: ?>
        <?php foreach ($reports as $report): ?>
            <div class="report-card">

                <div class="report-content">
                    <div class="report-details">
                        <div class="report-header">
                            <div class="report-info-with-badges">
                                <h3><?php echo htmlspecialchars($report['name']); ?></h3>
                                <div class="badges-inline">
                                    <div class="status-badge status-<?php echo $report['status']; ?>">
                                        <?php echo ucwords(str_replace('_', ' ', $report['status'])); ?>
                                    </div>
                                    <div class="concern-badge concern-<?php echo $report['concern_level']; ?>">
                                        <?php echo ucfirst($report['concern_level']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="report-meta">
                                <?php echo htmlspecialchars($report['phone']); ?> |
                                <?php echo htmlspecialchars($report['city'] . ', ' . $report['state']); ?> |
                                <?php echo date('M j, Y g:i A', strtotime($report['created_at'])); ?>
                            </div>
                        </div>
                        <p><strong>Issue Type - </strong> <?php echo ucwords(str_replace('_', ' ', $report['issue_type'])); ?></p>

                        <?php if (!empty($report['location_name'])): ?>
                            <p><strong>Location - </strong> <?php echo htmlspecialchars($report['location_name']); ?></p>
                        <?php endif; ?>

                        <?php if (!empty($report['latitude']) && !empty($report['longitude'])): ?>
                            <p><strong>Coordinates - </strong>
                                <span class="coordinates">
                                    <?php echo $report['latitude'] . ', ' . $report['longitude']; ?>
                                </span>
                                <a href="https://www.google.com/maps?q=<?php echo $report['latitude'] . ',' . $report['longitude']; ?>"
                                   target="_blank">View on Map</a>
                            </p>
                        <?php endif; ?>

                        <p><strong>Description</strong></p>
                        <p style="margin-top: 5px; line-height: 1.6; color: #0A192F;">
                            <?php echo nl2br(htmlspecialchars($report['issue_description'])); ?>
                        </p>

                        <?php if ($report['updated_at'] !== $report['created_at']): ?>
                            <p style="font-size: 12px; color: #0A192F; margin-top: 12px;">
                                <em>Last updated : <?php echo date('M j, Y g:i A', strtotime($report['updated_at'])); ?></em>
                            </p>
                        <?php endif; ?>
                        <div class="report-actions">
                            <form method="POST" style="display: inline-flex; align-items: center; gap: 12px;">
                                <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                <select name="new_status" class="status-select">
                                    <option value="pending" <?php echo $report['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="under_review" <?php echo $report['status'] === 'under_review' ? 'selected' : ''; ?>>Under Review</option>
                                    <option value="confirmed" <?php echo $report['status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                    <option value="declined" <?php echo $report['status'] === 'declined' ? 'selected' : ''; ?>>Declined</option>
                                    <option value="finished" <?php echo $report['status'] === 'finished' ? 'selected' : ''; ?>>Finished</option>
                                </select>
                                <button type="submit" name="update_status" class="update-btn">Update</button>
                            </form>

                            <form method="POST" style="display: inline;"
                                  onsubmit="return confirm('Are you sure you want to delete this report? This action cannot be undone.');">
                                <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                <button type="submit" name="delete_report" class="delete-btn">Delete</button>
                            </form>
                        </div>
                    </div>
                    <?php if (!empty($report['image_path']) && file_exists($report['image_path'])): ?>
                        <div class="report-image-section">
                            <img src="<?php echo htmlspecialchars($report['image_path']); ?>"
                                 alt="Report Image"
                                 class="report-image"
                                 onclick="window.open(this.src, '_blank')">
                        </div>
                    <?php else: ?>
                        <div class="report-image-section">
                            <div class="no-image-placeholder">
                                <p>No Image Available</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        <?php endforeach; ?>
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($status_filter); ?>&issue_type=<?php echo urlencode($issue_type_filter); ?>&concern_level=<?php echo urlencode($concern_level_filter); ?>&state=<?php echo urlencode($state_filter); ?>&city=<?php echo urlencode($city_filter); ?>">← Previous</a>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>&issue_type=<?php echo urlencode($issue_type_filter); ?>&concern_level=<?php echo urlencode($concern_level_filter); ?>&state=<?php echo urlencode($state_filter); ?>&city=<?php echo urlencode($city_filter); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($status_filter); ?>&issue_type=<?php echo urlencode($issue_type_filter); ?>&concern_level=<?php echo urlencode($concern_level_filter); ?>&state=<?php echo urlencode($state_filter); ?>&city=<?php echo urlencode($city_filter); ?>">Next →</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

     <?php endif; ?>
   </main>
    </div>
    <script>
        window.addEventListener('load', function() {
            if (typeof google !== 'undefined' && google.translate) {
                google.translate = null;
            }
                        const googleElements = document.querySelectorAll('[class*="google"], [id*="google"], .skiptranslate, #google_translate_element');
            googleElements.forEach(el => el.remove());
        });
        window.google_translate_element = null;
                Chart.defaults.color = '#E2E8F0';
        Chart.defaults.borderColor = 'rgba(226, 232, 240, 0.1)';
        Chart.defaults.backgroundColor = 'rgba(226, 232, 240, 0.05)';
        const statusData = <?php echo json_encode($status_stats); ?>;
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'bar',
            data: {
                labels: Object.keys(statusData).map(key => key.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())),
                datasets: [{
                    label: 'Reports',
                    data: Object.values(statusData),
                   backgroundColor:[
    '#F3F4F6',  
    '#0A0A0A',  
     '#F3F4F6', 
    '#0A0A0A',  
   '#F3F4F6',  
    '#0A0A0A', 
     '#F3F4F6',  
    '#0A0A0A',  
],

 borderColor: [
  '#F3F4F6',  
    '#0A0A0A', 
 '#F3F4F6',  
    '#0A0A0A', 
     '#F3F4F6',
    '#0A0A0A', 
 '#F3F4F6',  
    '#0A0A0A', 
],
                    borderWidth: 1,
                    borderRadius: 8,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(226, 232, 240, 0.1)'
                        },
                        ticks: {
                            color: '#94A3B8'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#94A3B8'
                        }
                    }
                }
            }
        });

                const issueData = <?php echo json_encode($issue_type_stats); ?>;
const issueCtx = document.getElementById('issueChart').getContext('2d');

const backgroundColors = [
   '#F3F4F6', 
    '#0A0A0A',
     '#F3F4F6',
    '#0A0A0A', 
   '#F3F4F6',  
    '#0A0A0A', 
     '#F3F4F6',
    '#0A0A0A', 
];

const borderColors = [
    '#F3F4F6', 
    '#0A0A0A', 
     '#F3F4F6',
    '#0A0A0A', 
   '#F3F4F6',  
    '#0A0A0A', 
     '#F3F4F6',
    '#0A0A0A', 
];
new Chart(issueCtx, {
    type: 'bar',
    data: {
        labels: Object.keys(issueData).map(key => key.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())),
        datasets: [{
            label: 'Reports',
            data: Object.values(issueData),
            backgroundColor: backgroundColors, 
            borderColor: borderColors,      
            borderWidth: 1,
            borderRadius: 8,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#94A3B8'
                }
            },
            x: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(226, 232, 240, 0.1)'
                },
                ticks: {
                    color: '#94A3B8'
                }
            }
        }
    }
});
const concernData = <?php echo json_encode($concern_stats); ?>;
const concernCtx = document.getElementById('concernChart').getContext('2d');
new Chart(concernCtx, {
    type: 'doughnut',
    data: {
        labels: Object.keys(concernData).map(key => key.charAt(0).toUpperCase() + key.slice(1)),
        datasets: [{
            data: Object.values(concernData),
            backgroundColor: [
                '#0A0A0A',
                '#5E5E69', 
                '#2F2F3B', 
                '#F3F4F6'  
            ],
            borderColor: [], 
            borderWidth: 0 
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right',
                labels: {
                    padding: 20,
                    usePointStyle: true,
                    color: '#0A192F'
                }
            }
        }
    }
});
const stateData = <?php echo json_encode($state_stats); ?>;
const stateCtx = document.getElementById('stateChart').getContext('2d');
new Chart(stateCtx, {
    type: 'bar',
    data: {
        labels: Object.keys(stateData),
        datasets: [{
            label: 'Reports',
            data: Object.values(stateData),
            backgroundColor: [
              '#0A0A0A', 
                '#5E5E69',
            ],
            borderColor: [
             '#0A0A0A', 
                '#5E5E69',
            ],
            borderWidth: 1,
            borderRadius: 8,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false 
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(226, 232, 240, 0.1)'
                },
                ticks: {
                    color: '#94A3B8'
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#94A3B8',
                    maxRotation: 45, 
                    minRotation: 0
                }
            }
        }
    }
});

        function loadCities(state) {
            const citySelect = document.getElementById('citySelect');
                        citySelect.innerHTML = '<option value="">All Cities</option>';
            
            if (state === '') {
                return;
            }
                        fetch('get_cities.php?state=' + encodeURIComponent(state))
                .then(response => response.json())
                .then(cities => {
                    cities.forEach(city => {
                        const option = document.createElement('option');
                        option.value = city;
                        option.textContent = city;
                        if (city === '<?php echo $city_filter; ?>') {
                            option.selected = true;
                        }
                        citySelect.appendChild(option);
                    });
                })
                .catch(error => {
                    console.error('Error loading cities:', error);
                });
        }
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-20px)';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });
        });
                document.querySelectorAll('form').forEach(form => {
            if (form.querySelector('[name="update_status"]')) {
                form.addEventListener('submit', function(e) {
                    const select = form.querySelector('[name="new_status"]');
                    if (!confirm(`Are you sure you want to change the status to "${select.options[select.selectedIndex].text}"?`)) {
                        e.preventDefault();
                    }
                });
            }
        });
        document.addEventListener('DOMContentLoaded', function() {
            const stateSelect = document.getElementById('stateSelect');
            if (stateSelect.value) {
                loadCities(stateSelect.value);
            }
        });
    </script>
</body>
</html>