<?php
session_start();

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit();
}

$error_message = '';

if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the message after displaying
}

if ($_POST) {
    $host = 'localhost';
    $dbname = 'community_tracker';
    $db_username = 'root';
    $db_password = '';
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_username, $db_password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
    
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT id, username, password, full_name FROM admin_users WHERE username = ? AND status = 'active'");
        $stmt->execute([$username]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($admin && $password === $admin['password']) {
            $update_stmt = $pdo->prepare("UPDATE admin_users SET last_login = NOW() WHERE id = ?");
            $update_stmt->execute([$admin['id']]);
            
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_full_name'] = $admin['full_name'];
            
            header('Location: dashboard.php');
            exit();
        } else {
            $error_message = 'Invalid username or password!';
            $_SESSION['error_message'] = $error_message;
            header('Location: login.php');
            exit();
        }
    } else {
        $error_message = 'Please enter both username and password!';
        $_SESSION['error_message'] = $error_message;
        header('Location: login.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Community Tracker</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F3F4F6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: #E5E7EB;
            border-radius: 30px;
               padding: 20px;
  border: 1px solid rgba(0, 0, 0, 0.03);
      box-shadow:
      0 2px 4px rgba(0, 0, 0, 0.04),
      0 4px 8px rgba(0, 0, 0, 0.03);
            width: 100%;
            max-width: 400px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .login-header h1 {
            color:  #0A0A0A;
            font-size: 24px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        
        .login-header p {
              color:  #0A0A0A;
            font-size: 16px;
        }
        
        .form-group {
            margin-bottom: 30px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: #0A0A0A;
        }
        
        .form-group input {
    width: 100%;
    padding: 10px 0;
    border: none;
    border-bottom: 2px solid #0A0A0A;
    background: transparent;
    font-size: 16px;
    color: #0A0A0A; 
    transition: border-color 0.3s ease;
}

.form-group input:focus {
    outline: none;
    border-bottom-color: #1D1D24;
}

        
        .login-btn {
            width: 100%;
            padding: 12px 24px;
            background: #0A0A0A;
            color: #E5E7EB;
            border: 2px solid #0A0A0A;
            border-radius: 20px;
            font-size: 16px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        
        .login-btn:hover {
            border: 2px solid #0A0A0A;
            color: #0A0A0A;
            background-color:  #E5E7EB;
        }
        
        .error-message {
            background: #E2E8F0;
            color: #DC2626 ;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            border: 1px solid #E2E8F0;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 30px;
            color: #0A0A0A;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Admin Login</h1>
            <p>Community Tracker Dashboard</p>
        </div>
        
        <?php if ($error_message): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required 
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-btn">Login</button>
        </form>
        
        <div class="footer">
            <p>&copy; 2025 Community Tracker System</p>
        </div>
    </div>
</body>
</html>