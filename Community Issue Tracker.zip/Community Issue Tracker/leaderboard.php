<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit();
}

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT id, first_name, last_name, points 
                       FROM users 
                       ORDER BY points DESC, id ASC");
$stmt->execute();
$allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$userPoints = 0;
$userRank = 0;
foreach ($allUsers as $index => $u) {
    if ($u['id'] == $userId) {
        $userPoints = $u['points'];
        $userRank = $index + 1;
        break;
    }
}

$top10 = array_slice($allUsers, 0, 10);
?>

<!DOCTYPE html>
<html lang="en">
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<head>
  <meta charset="UTF-8">
  <title>Leaderboard</title>
  <style>
    body {
    font-family: 'Inter', sans-serif;
      background: #f5f5f5;
      margin: 0;
      padding: 0;
    }
    .container {
      margin:0 auto;
      padding: 40px 20px;
    }
    h2 {
      text-align: center;
      font-size: 24px;
      line-height: 1;
      color: #0A0A0A;
      margin-bottom: 32px;
    }
    .user-info {
      text-align: center;
      color: #0A0A0A;
      margin-bottom: 32px;
    }
    .user-info p {
      display: flex;
      justify-content: center;
      gap: 40px; 
      margin: 0;
      color: #0A0A0A;
      font-size: 16px;
      line-height: 1.5;
    }

    .leaderboard-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 24px;
      margin: 10px 0;
      border-radius: 32px;
      background: #E5E7EB;
    }
 .leaderboard-item.first {
  background: #E6BE8A;
  font-weight: bold;
}
.leaderboard-item.second {
  background: #D9D9D9;
  font-weight: bold;
}
.leaderboard-item.third {
  background: #E0BFB8; 
  font-weight: bold;

}

    .name {
      text-align: left;
    }
    .points {
      text-align: right;
    }
  </style>
</head>
<body>
      <div class ="body-maincontainer">
<nav class="mobile-nav">
  <a href="home.php" class="nav-item">
    <img src="./communityimage/icon1.png" alt="Home">
    <span>Home</span>
  </a>
  <a href="report.php" class="nav-item">
    <img src="./communityimage/icon2.png" alt="Search">
    <span>Report</span>
  </a>
  <a href="aboutus.php" class="nav-item">
    <img src="./communityimage/icon3.png" alt="Alerts">
    <span>About Us</span>
  </a>
  <a href="contact.php" class="nav-item">
    <img src="./communityimage/icon4.png" alt="Profile">
    <span>Contact</span>
  </a>
  <a href="check_profile.php" class="nav-item">
    <img src="./communityimage/icon25.png" alt="Profile">
    <span>Profile</span>
  </a>
</nav>
  <div class="container">
    <h2>Leaderboard</h2>

    <div class="user-info">
      <p>
        <span>Your Rank : <?php echo $userRank; ?></span>
        <span>Your Points : <?php echo $userPoints; ?></span>
      </p>
    </div>

    <?php foreach ($top10 as $i => $row): 
    $rank = $i + 1;
    $class = '';
    if ($rank === 1) $class = ' first';
    elseif ($rank === 2) $class = ' second';
    elseif ($rank === 3) $class = ' third';
?>
  <div class="leaderboard-item<?php echo $class; ?>">
    <span class="name"><?php echo $rank . ". " . htmlspecialchars($row['first_name'] . " " . $row['last_name']); ?></span>
    <span class="points"><?php echo $row['points']; ?></span>
  </div>
<?php endforeach; ?>

  </div>
  </div>
</body>
</html>
