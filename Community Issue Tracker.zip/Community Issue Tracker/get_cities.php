<?php
require_once 'config.php';

header('Content-Type: application/json');

if (isset($_GET['state'])) {
    $state = sanitize($_GET['state']);
    
    try {
        $stmt = $pdo->prepare("SELECT city FROM myanmar_locations WHERE state = ? ORDER BY city");
        $stmt->execute([$state]);
        $cities = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo json_encode($cities);
    } catch (PDOException $e) {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}
?>