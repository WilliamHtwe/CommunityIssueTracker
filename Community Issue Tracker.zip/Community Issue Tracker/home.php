<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Issue Tracker </title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class ="body-maincontainer">
<nav class="mobile-nav">
  <a href="home.php" class="nav-item">
    <img src="./communityimage/icon1.png" alt="Home">
    <span>Home</span>
  </a>
  <a href="report.php" class="nav-item">
    <img src="./communityimage/icon2.png" alt="Search">
    <span>Report</span>
  </a>
  <a href="aboutus.php" class="nav-item">
    <img src="./communityimage/icon3.png" alt="Alerts">
    <span>About Us</span>
  </a>
  <a href="contact.php" class="nav-item">
    <img src="./communityimage/icon4.png" alt="Profile">
    <span>Contact</span>
  </a>
  <a href="check_profile.php" class="nav-item">
    <img src="./communityimage/icon25.png" alt="Profile">
    <span>Profile</span>
  </a>
</nav>

<div class="hero">
  <div class="hero-content">
    <h1>Your Voice for Safer<br> <span>Communities</span></h1>
  </div>


  <div class="hero-box">
    <div class="percent-container">
      <span class="percent">75%</span>
      <span class="time-reduced">Solved Problems</span>
    </div>
    <div class="progress-fill"></div>
  </div>

  <div class="three-boxes">
    <div class="left-boxes">
<div class="box" style="height: 150px; position: relative; padding: 20px;">
  <img src="./communityimage/icon6.png" class="box-icon" alt="icon">
  <span class="bottom-left-text fixed-bottom-left">Every report matters</span>
</div>

<div class="box" style="height: 150px; margin-top: 20px; position: relative; padding: 20px;">
  <img src="./communityimage/icon7.png" class="box-icon" alt="icon">
  <span class="bottom-left-text fixed-bottom-left">Available in 13 States</span>
</div>
</div>
  <div class="right-box">
    <div class="box" style="height: 320px; background-image: url('./communityimage/image5.png'); background-size: cover; background-position: center;"></div>
  </div>
</div>
</div>

<div class="report-box">
  <h2 class="report-header">Report an Issue</h2>
  <p class="report-text">
    See a hazard? Don’t wait — report it now and make it count.
  </p>
  <a href="report.php" class="report-btn">
    <span>Report</span>
    <span class="btn-icon">
    <img src="./communityimage/icon8.png" alt="" />
    </span>
  </a>
</div>
<div class="two-boxes">
  <div class="stat-box">
    <span class="top-text">Resolved</span>
    <span class="bottom-text">87%</span>
  </div>
  <div class="stat-box">
    <span class="top-text">Reports</span>
    <span class="bottom-text">12k</span>
  </div>
</div>
<div class="issue-category-main-container">
        <h2 class="issue-category-page-title">Issue Category</h2>
        
        <div class="issue-category-selection-container">
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon9.png" alt="Road Issues">
                </span>
                <span>Road Issues</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon10.png" alt="Bridge Problems">
                </span>
                <span>Bridge Problems</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon11.png" alt="Water Supply">
                </span>
                <span>Water Supply</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon12.png" alt="Electricity">
                </span>
                <span>Electricity</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon13.png" alt="Waste Management">
                </span>
                <span>Waste Management</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon14.png" alt="Street Lighting">
                </span>
                <span>Street Lighting</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon15.png" alt="Drainage System">
                </span>
                <span>Drainage System</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon16.png" alt="Safety Issues">
                </span>
                <span>Safety Issues</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon17.png" alt="Environmental">
                </span>
                <span>Environmental</span>
            </button>
            <button class="issue-category-button">
                <span class="issue-category-icon">
                    <img src="./communityimage/icon18.png" alt="Other">
                </span>
                <span>Other</span>
            </button>
        </div>
    </div>
<h2 class="news-heading">Latest Updates</h2>

<div class="news-box">
  <span class="news-badge">Beta Version</span>
  <p class="news-text">We are testing this app to prepare it for nationwide use.</p>
</div>

    </div>
<script> 
        document.querySelectorAll('.issue-category-button').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.issue-category-button').forEach(b => b.classList.remove('active'));
                
                this.classList.add('active');
                
                const category = this.textContent.trim();
                console.log('Selected category:', category);
            });
        });
    </script>
</body>
</html>